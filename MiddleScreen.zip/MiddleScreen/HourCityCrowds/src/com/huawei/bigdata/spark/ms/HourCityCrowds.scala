package com.huawei.bigdata.spark.ms

import com.redislabs.provider.redis._
import org.apache.hadoop.hbase.client.Scan
import org.apache.hadoop.hbase.filter.{CompareFilter, RegexStringComparator, RowFilter}
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.hadoop.io.NullWritable
import org.apache.hadoop.mapred.lib.MultipleTextOutputFormat
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.ArrayBuffer

object HourCityCrowds {
    def main(args: Array[String]): Unit = {
        val Array(redisHost, redisPort, _0or1, time, tableName) = args
        val sc = new SparkContext(new SparkConf()
                .setAppName("HourCityCrowds" + time)
                .set("spark.redis.host", args(0))
                .set("spark.redis.port", args(1))
        )
        //args（3）是传入的日期
        //读取当天全国的5分钟切片程序
        val hbaseContext = new HBaseContext(sc, getHbaseConnection())
        val scan = new Scan()
        val filter = new RowFilter(CompareFilter.CompareOp.EQUAL, new RegexStringComparator(".*(" + args(3) + ").*$"))
        scan.setFilter(filter)
        val bs_city: RDD[(String, String)] = sc.fromRedisHash("cell_city")
        val pd_imsi = if (args(2).equals("1")) { //1 按人在最后时间的一个
            val crowds = hbaseContext.hbaseRDD(TableName.valueOf(tableName), scan).map(crowds => {
                val keyRow = Bytes.toString(crowds._2.getRow);
                val base_station = keyRow.split("_", -1)(1) + "_" + keyRow.split("_", -1)(2) + "_" + keyRow.split("_", -1)(3);
                val time = keyRow.split("_", -1)(4)
                val cells = crowds._2.rawCells()
                val dayArray = ArrayBuffer[(String, String)]()
                for (cell <- cells) {
                    val columnName = Bytes.toString(CellUtil.cloneQualifier(cell))
                    //获取对应时间片数据
                    val imsi = Bytes.toString(CellUtil.cloneValue(cell))
                    val imsiArray = imsi.split(",")
                    for (imsi <- imsiArray) {
                        dayArray += new Tuple2(base_station, time + "_" + columnName + "_" + imsi)
                    }
                }
                dayArray.toList
            })
            val crowdsFlat: RDD[(String, String)] = crowds.flatMap(x => x)
            val imsi_city = crowdsFlat.join(bs_city).map(x => {
                val imsi = x._2._1.split("_", -1)(2)
                val tc = x._2._1.split("_", -1)(0) + "_" + x._2._1.split("_", -1)(1) + "_" + x._2._2
                (imsi, tc) // imsi,time_columnName_city
            })


            val crowdsNew = imsi_city.reduceByKey((x, y) => {
                if ((x.split("_", -1)(0) + x.split("_", -1)(1)).toLong > (x.split("_", -1)(0) + x.split("_", -1)(1)).toLong) {
                    x
                }
                else {
                    y
                }
            }).map(x => (x._2.split("_", -1)(2) + ":" + x._2.split("_", -1)(0), x._1))
            crowdsNew
        } else { // 0 是按累计时间排序最多的一个
            val crowdsByStayTime = hbaseContext.hbaseRDD(TableName.valueOf(tableName), scan)
                    .map(crowds => {
                        val keyRow = Bytes.toString(crowds._2.getRow);
                        val base_station = keyRow.split("_", -1)(1) + "_" + keyRow.split("_", -1)(2) + "_" + keyRow.split("_", -1)(3);
                        val time = keyRow.split("_", -1)(4)
                        val cells = crowds._2.rawCells()
                        val num = 1
                        val dayArray = ArrayBuffer[(String, String)]()
                        for (cell <- cells) {
                            val columnName = Bytes.toString(CellUtil.cloneQualifier(cell))
                            //获取对应时间片数据
                            val imsi = Bytes.toString(CellUtil.cloneValue(cell))
                            val imsiArray = imsi.split(",", -1)
                            for (imsi <- imsiArray) {
                                dayArray += new Tuple2(base_station, time + "_" + columnName + "_" + num + "_" + imsi)
                            }
                        }
                        dayArray.toList //base_station, time +"_"+ columnName+"_"+num+ "_" +imsi
                    })
            val imsi_c: RDD[(String, String)] = crowdsByStayTime.flatMap(x => x)
            val imsi_city = imsi_c.join(bs_city).map(x => { //(time +"_"+ columnName+"_"+num+ "_" +imsi,city)
                val imsi_city = x._2._1.split("_", -1)(3) + "_" + x._2._2
                val tc_num = x._2._1.split("_", -1)(0) + "_" + x._2._1.split("_", -1)(1) + "_" + x._2._1.split("_", -1)(2)
                //imsi+ "_" + province, time +"_"+ columnName+"_"+num
                (imsi_city, tc_num) // imsi,time_columnName_city
            })
            val imsip_num: RDD[(String, String)] = imsi_city.reduceByKey((x, y) => {
                val num1: Int = x.split("_", -1)(2).toInt
                val num2: Int = y.split("_", -1)(2).toInt
                val num: Int = num1 + num2
                x.split("_", -1)(0) + "_" + x.split("_", -1)(1) + "_" + num
            })
            val imsi_pnum: RDD[(String, String)] = imsip_num.map(x => {
                val imsi = x._1.split("_", -1)(0)
                val province = x._1.split("_", -1)(1)
                val time = x._2.split("_", -1)(0)
                val num = x._2.split("_", -1)(2)
                (imsi, province + "_" + time + "_" + num)
            })
            val imsi_max: RDD[(String, String)] = imsi_pnum.reduceByKey((x, y) => {
                if (x.split("_", -1)(2).toInt > y.split("_", -1)(2).toInt) {
                    x
                } else {
                    y
                }
            })
            //province:dt,imsi
            val pd_imsi: RDD[(String, String)] = imsi_max.map(x => (x._2.split("_", -1)(0) + ":" + x._2.split("_", -1)(1), x._1)) //province:dt,imsi
            pd_imsi
        }

        pd_imsi.saveAsHadoopFile("hdfs://ns2/Intermediate/ODS/TO_H_EVNT_NS_PROV_IMSI_MAP/" + args(3) + "/", classOf[String], classOf[String],
            classOf[RDDMultipleTextOutputFormat])


        sc.stop()
    }


    /**
     * 获取Hbase连接
     *
     * @return
     */
    def getHbaseConnection() = {
        val conf = HBaseConfiguration.create;
        conf.set("hadoop.security.authentication", "kerberos");
        conf.set("hbase.security.authentication", "kerberos");
        val master_principal = "hbase/_HOST@ZHKDC";
        val regionserver_principal = "hbase/_HOST@ZHKDC";
        val krb5_conf = "/etc/krb5.conf";
        System.setProperty("java.security.krb5.conf", krb5_conf)
        conf.set("hbase.master.kerberos.principal", master_principal)
        conf.set("hbase.regionserver.kerberos.principal", regionserver_principal)
        conf.set("hbase.zookeeper.quorum", "hebsjzx-wzjd-master-28-7,hebsjzx-wzjd-master-28-4,hebsjzx-wzjd-master-28-14")
        conf.set("hbase.zookeeper.property.clientPort", "2181")
        conf.set("zookeeper.znode.parent", "/hbase-secure")
        conf
    }


}

class RDDMultipleTextOutputFormat extends MultipleTextOutputFormat[Any, Any] {
    override def generateActualKey(key: Any, value: Any): Any =
        NullWritable.get()

    override def generateFileNameForKeyValue(key: Any, value: Any, name: String): String =
        key.toString.split(":")(0) + "/" + "result" + "/" + name
}