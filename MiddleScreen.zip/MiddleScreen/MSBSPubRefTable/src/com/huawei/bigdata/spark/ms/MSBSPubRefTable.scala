package com.huawei.bigdata.spark.ms

import java.io.File
import java.util.Properties

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}


object MSBSPubRefTable {
    // topic和省编码映射表
    val provinceMap: Map[String, String] = Map(
        "10100" -> "110000",
        "10200" -> "310000",
        "10300" -> "120000",
        "10400" -> "500000",
        "10500" -> "520000",
        "10600" -> "420000",
        "10700" -> "610000",
        "10800" -> "130000",
        "10900" -> "410000",
        "11000" -> "340000",
        "11100" -> "350000",
        "11200" -> "630000",
        "11300" -> "620000",
        "11400" -> "330000",
        "11600" -> "230000",
        "11700" -> "320000",
        "11800" -> "220000",
        "11900" -> "640000",
        "12000" -> "370000",
        "12100" -> "140000",
        "12200" -> "650000",
        "12300" -> "440000",
        "12400" -> "210000",
        "12500" -> "450000",
        "12600" -> "430000",
        "12700" -> "360000",
        "12800" -> "150000",
        "12900" -> "530000",
        "13000" -> "510000",
        "13100" -> "540000",
        "11500" -> "460000"
    )
    def main(args: Array[String]): Unit = {
        if (args.length != 9) {
            println("MSBSPubRefTable {pathRoot4g} {pathRoot2g} {date} {url} {user} {password} {host} {port} {appName} are missing argument")
            return
        }


        //4G根路径
        val pathRoot4g = args(0)
        //2G根路径
        val pathRoot2g = args(1)
        //日期yyyyMMdd
        val date = args(2)
        //mysql参数，url,user,password
        val url = args(3)
        val user = args(4)
        val password = args(5)
        //redis参数 ip,port
        val host = args(6)
        val port = args(7)
        val appName = args(8)

        val spark = SparkSession.builder().appName(appName)
          .config("spark.redis.host", host)
          .config("spark.redis.port", port)
          .enableHiveSupport()
          .getOrCreate()

        import com.redislabs.provider.redis._
        val path4g = pathRoot4g + File.separator + "statis_day=" + date
        val path2g = pathRoot2g + File.separator + "statis_day=" + date

        //配置mysql数据库参数
        val prop = new Properties()
        prop.setProperty("user", user)
        prop.setProperty("password", password)


        import spark.implicits._

        /*
        读取4G工参表数据转为Row，字段(
         row(0):MCC   row(1):MNC  row(2):TAC_CD   row(3):PCI  row(4):CELL_CD  row(5):Latitude row(6):Longitude    row(7):City_Name    row(8):base_station
         row(9):E_NODEB   row(10):Cell_Name   row(11):Cell_Type   row(12):Area_Type   row(13):Location_area   row(14):Location_Area_Name  row(15):City    row(16):District    row(17):Air_High
        row(18):Electronic_Dip   row(19):Mechanical_Tilt     row(20):CMCC_Sign   row(21):province    row(22):region_name     row(23):district_name)
        */
        val data4g = spark.sparkContext.textFile(path4g).map(_.split("\\|\\|", -1)).map(row => Row(
            row(0), row(1), row(2), row(3), row(4), row(5), row(6), row(7), row(8), row(9), row(10), row(11), row(12), row(13), row(14), row(15), row(16), row(17), row(18), row(19), row(20), row(21), row(22), row(23)
        )).filter(row=>{row(5).toString.trim.length>0&&row(6).toString.trim.length>0})

        /*
        读取23G工参表数据转为Row,字段(
         row(0):MCC   row(1):MNC  row(2):PLACE_CD     row(3)CELL_CD   row(4):Latitude     row(5):Longitude    row(6):City_Name    row(7):base_station
         row(8):BTS_Name      row(9):Cell_Name    row(10):Cell_Type   row(11):Area_Type   row(12):Location_area   row(13):Location_Area_Name  row(14):City    row(15)District     row(16):CMCC_Sign
         row(17):Electronic_Dip   row(18):Mechanical_Tilt     row(19):CMCC_Sign   row(20):province    row(21):region_name     row(22):District_Name)

        */
        val data2g = spark.sparkContext.textFile(path2g).map(_.split("\\|\\|", -1)).map(row => Row(
            row(0), row(1), row(2), row(3), row(4), row(5), row(6), row(7), row(8), row(9), row(10), row(11), row(12), row(13), row(14), row(15), row(16), row(17), row(18), row(19), row(20), row(21), row(22)
        )).filter(row=>{row(4).toString.trim.length>0&&row(5).toString.trim.length>0})

        /*
         合并数据,字段(
         row(2):TAC_CD    row(4):CELL_CD  row(5):Latitude     row(6):Longitude
         row(10):Cell_Name    row(11):Cell_Type   row(12):Area_Type   row(13):Location_area,
         row(14):Location_Area_Name   row(15):City    row(16):District    row(20):CMCC_Sign   4g)
        */
        val unionRdd = data4g.map(row => Row(row(2), row(4), row(5), row(6), row(10), row(11), row(12), row(13), row(14), row(15), row(16), row(20), "4g")).union(data2g.map(row => Row(row(2), row(3), row(4), row(5), row(9), row(10), row(11), row(12), row(13), row(14), row(15), row(19), "2g")))

        /*
        生成工参表所需数据，字段(
         row(2):cgi_lat   row(3):cgi_lng  row(14):net_type
         row(13):cmcc_sign    row(12):district    row(11):city   row(7):cell_type   row(6):cell_name
         row(9):location_area     row(8):area_type    row(10)location_area_name)
        */
        val rowTuple: RDD[(String, Row)] = unionRdd.map(row => {
            val cgi_code: String = provinceMap.get(row(11).toString).get + "_" + row(0).toString + "_" + row(1).toString
            (cgi_code,Row(
                cgi_code, row(2), row(3), row(12), row(11), row(10), row(9), row(5), row(4), row(7), row(6), row(8)
            ))
        }).reduceByKey((x,y)=>{y})





        //方式二：采用spark的dataSet将数据存入mysql
        //构建row 字段(
        //      row(0):cgi_code " "=cgi_name   row(1):cgi_lat   row(2):cgi_lng  " "=is_indoor   row(3):net_type
        //         row(4):cmcc_sign    row(5):district    row(6):city   row(7):cell_type   row(8):cell_name
        //         row(9):location_area     row(10):area_type    row(11)location_area_name)
        val resultRow=rowTuple.map(rowTuple=>{
            val row=rowTuple._2
            (row(5).toString, Row(row(0),row(1).toString.trim.toDouble,row(2).toString.trim.toDouble,row(3),row(4),row(5),row(7),row(8),row(9),row(10),row(11))
            )})

        val countryCityRDD = spark.sql("select cityid, countyid  from DIM.T_DIM_ID_REGIONAL_MAPPING").rdd
        val countryCity = countryCityRDD.map(row => {
            val cityid = row.getAs[String]("cityid")
            val countyid = row.getAs[String]("countyid")
            (countyid, cityid)
        })

        val resultCityRow=countryCity.join(resultRow).map(line=>{
            val row=line._2._2
            val city=line._2._1.toString
            Row(row(0),"",row(1).toString.trim.toDouble,row(2).toString.trim.toDouble,"",row(3),row(4),row(5),city,row(6),row(7),row(8),row(9),row(10))
        })

        //构建StructType
        val structe = StructType(Seq(
            StructField("cgi_code", StringType),
            StructField("cgi_name", StringType),
            StructField("cgi_lat", DoubleType),
            StructField("cgi_lng", DoubleType),
            StructField("is_indoor", StringType),
            StructField("net_type", StringType),
            StructField("cmcc_sign", StringType),
            StructField("district", StringType),//关联countyid
            StructField("city", StringType),
            StructField("cell_type", StringType),
            StructField("cell_name", StringType),
            StructField("location_area", StringType),
            StructField("area_type", StringType),
            StructField("location_area_name", StringType)
        ))

        //创建基站与市映射,并存入redis
        //row(0):cgi_code   row(8):city
        val cityRow = resultCityRow.map(row => (row(0).toString, row(8).toString))
        spark.sparkContext.toRedisHASH(cityRow, "cell_city")


        //创建基站与省映射,并存入redis
        //row(0):cgi_code   row(6):cmcc_sign
        val proRow = resultCityRow.map(row => (row(0).toString, row(6).toString))
        spark.sparkContext.toRedisHASH(proRow, "cell_province")


        //创建基站与经纬度映射,并存入redis
        //row(0):cgi_code   row(2):cgi_lat  row(3):cgi_lng
        val locRow = resultCityRow.map(row => (row(0).toString, row(2).toString.trim + "," + row(3).toString.trim))
        spark.sparkContext.toRedisHASH(locRow, "cell_lat_lng")

        //用df将数据写入mysql,如果采用append模式，可能会出现重复值，表中不能建主键
        val df = spark.createDataFrame(resultCityRow, structe)
        df.write.mode("overwrite")
          .format("jdbc")
          .option("driver", "com.mysql.jdbc.Driver")
          .option("url", url)
          .option("dbtable", "t_lac_ci")
          .option("user", user)
          .option("password", password)
          .option("truncate","true")
          .save()

        spark.stop()


    }

}
