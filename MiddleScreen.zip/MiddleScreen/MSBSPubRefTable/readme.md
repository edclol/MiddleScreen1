#基站数据入库
<br />

##集团环境
spark-submit --class com.huawei.bigdata.spark.ms.MSBSPubRefTable --master yarn --num-executors 200 --executor-memory 20G --executor-cores 2 --driver-memory 5G --deploy-mode client --jars /home/huawei_wzjd_kafka/MiddleScreen/mysql-connector-java-5.1.47.jar,/home/huawei_wzjd_kafka/MiddleScreen/commons-pool2-2.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/spark-redis_2.11-2.4.2.jar,/home/huawei_wzjd_kafka/MiddleScreen/jedis-3.2.0.jar --principal huawei_wzjd_kafka@WZJDH --keytab huawei_wzjd_kafka.keytab --queue root.bdoc.huawei_wzjd_kafka --conf spark.storage.memoryFraction=0.5 --conf spark.network.timeout=360s --conf spark.shuffle.memoryFraction=0.4 --conf spark.yarn.executor.memoryOverhead=4096 --conf spark.ui.port=0 --conf "spark.ui.filters=" ./MiddleScreen/MSBSPubRefTable.jar hdfs://wzjdh/Intermediate/DIM/T_DIM_ID_GC_4G hdfs://wzjdh/Intermediate/DIM/T_DIM_ID_GC_23G 20200514 jdbc:mysql://10.252.30.208:3306/DWA_WZMF wzmf_monitor WZ!0604mfor 10.252.31.100 22400 MSBSPubRefTable

##集群运行环境执行参数
参数1：4G工参表输入路径<br />
参数2：2G工参表输入路径<br />
参数3：日期yyyyMMdd<br />
参数4：mysql的url(jdbc:mysql://10.247.15.58:3306/test)<br />
参数5：mysql的用户名<br />
参数6：mysql的密码<br />
参数7：redis的ip地址(例10.90.181.105)<br />
参数8：redis的端口号(例22400)<br />
##部署后业务机服务器目录结构
/readme.md &emsp; 帮助<br />
/pom.xml  &emsp;  编译文件<br />
/src/main/scala/com/huawei/bigdata/spark/bs/MSSnapshotDetails.scala &emsp;  主流程文件<br />
<br />



##V1.0.0 版本内容更新
* 读取将4G工参表和23G工参表数据，并分别抽取所需字段，然后union<br />
* 将union后的数据分别传入mysql和redis<br />
* 传入mysql时实现了更新操作，传入redis时根据要求分别传入三个HASH中<br />



