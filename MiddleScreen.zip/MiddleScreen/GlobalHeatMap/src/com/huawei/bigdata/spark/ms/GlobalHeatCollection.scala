package com.huawei.bigdata.spark.ms


import java.security.MessageDigest
import java.util
import java.util.Date

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.serializer.SerializerFeature
import com.redislabs.provider.redis._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.client.{Get, Result, Scan}
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable.ArrayBuffer


object GlobalHeatCollection {
    def main(args: Array[String]): Unit = {
        val Array(host, port, url, userName, pass) = args
        val sc = new SparkContext(new SparkConf()
                .setAppName("GlobalHeatCollection" + new Date())
                .set("spark.redis.host", args(0))
                .set("spark.redis.port", args(1))
        )

        //从redis中获取未执行数据
        val heatRedisRdd = sc.fromRedisHash("t_analy_task_id")

        //先进行过滤，保证数据都是未执行的数据，并且需要t_whole_heatchart_task和任务ID进行拼接 .filter(_._2.contains("0_heat"))
        val heatFilterRdd = heatRedisRdd.filter(_._2 == "0_heat").map("t_heat_task_" + _._1)
        val heatList = heatFilterRdd.collect()
        for (str <- heatList) {
            //通过t_whole_heatchart_task和主键ID拼接的key获取相应redis数据(2.	读取t_whole_heatchart_task+主键ID任务表，获取需要统计的范围和时间粒度)
            val heatchartRedisRdd = sc.fromRedisHash(str)

            //val heatchartRedisRdd = sc.fromRedisHash("t_heat_task_218393489816158208")

            val mt_MAP: collection.Map[String, String] = heatchartRedisRdd.collectAsMap()

            val time_stamp = mt_MAP.get("time_stamp").get
            val grained_type = mt_MAP.get("grained_type").get
            val province = mt_MAP.get("province").get
            val city = mt_MAP.get("city").get
            val district = mt_MAP.get("district").get
            //val district = mt_MAP.get("result").get
            val tableName = "DWV_WZMF:t_crowd_data"

            //cgi_code,lat,lng,
            val cgi_RDD = cgiIdFromMysql(sc, url, userName, pass, province, city, district)

            val hbase_Rowkey = if (grained_type == "DAY") {
                val rowKey: RDD[String] = cgi_RDD.map(x => {
                    // val tableName = "t_crowd_data_" + x._4
                    val dayArray = ArrayBuffer[String]()
                    //当为 DAY时，我们拼接一天24小时在后面
                    for (i <- 0 to 23) {
                        val md5 = getMD5Str(x._1)
                        val hbase_key = if (0 <= i && i <= 9) {
                            dayArray += md5 + "_" + x._1 + "_" + time_stamp + "0" + i
                        } else {
                            dayArray += md5 + "_" + x._1 + "_" + time_stamp + i
                        }
                    }
                    dayArray
                }).flatMap(x => x)
                rowKey
            } else {
                val rowKey: RDD[String] = cgi_RDD.map(x => {
                    // val tableName = "t_crowd_data
                    val md5 = getMD5Str(x._1)
                    md5 + "_" + x._1 + "_" + time_stamp
                })
                rowKey
            }


            val jsonMap = new util.HashMap[String, Any]();
            val personCount = cgiDataFromHbase(sc, hbase_Rowkey, tableName)

            val RDD_1heat: RDD[(String, String)] = sc.parallelize(List((str.split("_")(3), "1_heat")))
            sc.toRedisHASH(RDD_1heat, "t_analy_task_id")


            val lat_lngCnt = personCount.join(cgi_RDD).filter(_._1 != null).map(x => (x._1 + ":" + x._2._2, x._2._1)).sortBy(_._2, false).collect()

            var jsonList = new util.ArrayList[util.HashMap[String, String]]()
            //positions:{"crowd_lon":"116.399939","crowd_lat":"39.921369","total_num":"300"}
            for (arr <- lat_lngCnt) {
                val jsonMap = new util.HashMap[String, String]();
                val cgi_ll = arr._1.split(":")
                val cgi_code = cgi_ll(0)
                val lonlan = cgi_ll(1).split(",")
                jsonMap.put("crowd_lon", lonlan(1))
                jsonMap.put("crowd_lat", lonlan(0))
                jsonMap.put("total_num", arr._2 + "")
                jsonMap.put("cgi_code", cgi_code + "")
                jsonList.add(jsonMap)
            }
            jsonList

            if (!jsonList.isEmpty) {
                //对ArrayList进行json字符串转化
                val jsonString = JSON.toJSONString(jsonList, SerializerFeature.BeanToArray)
                //转成List[String,any]
                val resultData = sc.parallelize(Array(("positions", jsonString)));
                //把结果存储到Redis中
                sc.toRedisHASH(resultData, str)
                val RDD_2heat: RDD[(String, String)] = sc.parallelize(List((str.split("_")(3), "2_heat")))
                sc.toRedisHASH(RDD_2heat, "t_analy_task_id")
            } else {
                val RDD_0heat: RDD[(String, String)] = sc.parallelize(List((str.split("_")(3), "0_heat")))
                sc.toRedisHASH(RDD_0heat, "t_analy_task_id")
            }

        }

        sc.stop()
    }


    /**
     * 根据cgiId+时间戳去Hbase查询统计基站人群数量
     *
     * @param sc
     * @param cgiData
     * @return
     */
    def cgiDataFromHbase(sc: SparkContext, cgiData: RDD[String], tableName: String) = {
        // cell_lat_lon
        // 410000_18805_61828864
        //35.61375,114.19612
        val hbaseContext = new HBaseContext(sc, getHbaseConnection())
        //210000_16583_56008474，   42.94269,124.08813
        //10000_4302_227865807_2020072001 rowKey
        val cgi_Cnt = hbaseContext.bulkGet[String, (String, Int)](
            TableName.valueOf(tableName),
            61200,
            cgiData,
            record => {
                new Get(Bytes.toBytes(record)) //record？
            },
            (result: Result) => {
                //获取rowkey
                val rowkey = Bytes.toString(result.getRow)
                var cgiid: String = null
                var personnum: Int = 0
                if (rowkey != null) {
                    //切割rowkey，获取基站id
                    cgiid = rowkey.split("_")(1) + "_" + rowkey.split("_")(2) + "_" + rowkey.split("_")(3)
                    //获取列集合
                    val cells = result.rawCells()
                    for (cell <- cells) {
                        personnum = if (Bytes.toString(CellUtil.cloneValue(cell)).contains(",")) {
                            val personNum: Array[String] = Bytes.toString(CellUtil.cloneValue(cell)).split(",")
                            personNum.size
                        } else if (Bytes.toString(CellUtil.cloneValue(cell)) == null) {
                            0
                        } else {
                            1
                        }
                    }
                }
                (cgiid, personnum)
            }).filter(x => x._1 != null && x._2 != 0).reduceByKey(_ + _)
      
        cgi_Cnt
    }


    /**
     * 获取Hbase连接
     *
     * @return
     */
    def getHbaseConnection(): Configuration = {
        val conf = HBaseConfiguration.create;
        conf.set("hadoop.security.authentication", "kerberos");
        conf.set("hbase.security.authentication", "kerberos");
        val master_principal = "hbase/_HOST@ZHKDC";
        val regionserver_principal = "hbase/_HOST@ZHKDC";
        val krb5_conf = "/etc/krb5.conf";
        System.setProperty("java.security.krb5.conf", krb5_conf)
        conf.set("hbase.master.kerberos.principal", master_principal)
        conf.set("hbase.regionserver.kerberos.principal", regionserver_principal)
        conf.set("hbase.zookeeper.quorum", "hebsjzx-wzjd-master-28-7,hebsjzx-wzjd-master-28-4,hebsjzx-wzjd-master-28-14")
        conf.set("hbase.zookeeper.property.clientPort", "2181")
        conf.set("zookeeper.znode.parent", "/hbase-secure")
        conf
    }

    /**
     * 根据sql去mysql进行查询结果集并进行处理
     *
     * @param url
     * @param username
     * @param pass
     * @param province
     * @param city
     * @param district
     * @return
     */
    def cgiIdFromMysql(sc: SparkContext, url: String, username: String, pass: String, province: String, city: String, district: String) = {
        val spark: SparkSession = SparkSession.builder().appName("GlobalHeatCollection").getOrCreate()

        val reader = spark.read.format("jdbc")
                .option("url", url)
                .option("driver", "com.mysql.jdbc.Driver")
                .option("user", username)
                .option("password", pass)
                .option("dbtable", "t_lac_ci")
                .load()

        val city_lat_lng: RDD[(String, String)] = if (district != "null" && district != "" && district != null) {
            val df: DataFrame = reader.select("cgi_code", "cgi_lat", "cgi_lng").where("district=" + district)
            val rdd: RDD[Row] = df.rdd
            val city_lat_lng = rdd.map(row => {
                val cgi_code = row.getAs[String]("cgi_code")
                val cgi_lat = row.getAs[Double]("cgi_lat")
                val cgi_lng = row.getAs[Double]("cgi_lng")
                val provinc = cgi_code.split("_")(0)
                (cgi_code, cgi_lat + "," + cgi_lng)
            })
            city_lat_lng
        } else if (city != "null" && city != "" && city != null) {
            val df: DataFrame = reader.select("cgi_code", "cgi_lat", "cgi_lng").where("city=" + city)
            val rdd: RDD[Row] = df.rdd
            val city_lat_lng = rdd.map(row => {
                val cgi_code = row.getAs[String]("cgi_code")
                val cgi_lat = row.getAs[Double]("cgi_lat")
                val cgi_lng = row.getAs[Double]("cgi_lng")
                val provinc = cgi_code.split("_")(0)
                (cgi_code, cgi_lat + "," + cgi_lng)
            })
            city_lat_lng
        } else {
            val df: DataFrame = reader.select("cgi_code", "cgi_lat", "cgi_lng")
            val rdd: RDD[Row] = df.rdd
            val city_lat_lng = rdd.map(row => {
                val cgi_code = row.getAs[String]("cgi_code")
                val cgi_lat = row.getAs[Double]("cgi_lat")
                val cgi_lng = row.getAs[Double]("cgi_lng")
                val provinc = cgi_code.split("_")(0)
                (cgi_code, cgi_lat + "," + cgi_lng)
            }).filter(x => x._1.split("_", -1)(0) == province)
            city_lat_lng
        }

        city_lat_lng
    }

    //转MD5方法
    def getMD5Str(key: String): String = {
        val md5 = MessageDigest.getInstance("MD5")
        val md5Bytes = md5.digest(key.getBytes("UTF-8"))
        val bufferMd5 = new StringBuffer();
        for (i <- 0 to (md5Bytes.length - 1)) {
            val in = md5Bytes(i) & 0xff;
            if (in < 16) {
                bufferMd5.append("0")
            }
            bufferMd5.append(Integer.toHexString(in))
        }
        bufferMd5.toString()
    }

}
