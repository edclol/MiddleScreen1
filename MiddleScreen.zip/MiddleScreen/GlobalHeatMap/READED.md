
##集团测试成功的脚本
/usr/lib/spark/bin/spark-submit --class com.huawei.bigdata.spark.ms.GlobalHeatCollection --master yarn --deploy-mode client --principal huawei_wzjd_kafka --keytab huawei_wzjd_kafka.keytab --conf "spark.driver.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --conf "spark.executor.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --files ./MiddleScreen/conf/spark_jaas.conf,spark_kafka.keytab --conf "spark.driver.extraJavaOptions=-Djava.security.auth.login.config=./MiddleScreen/conf/kafka_client_jaas.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=./spark_jaas.conf" --conf spark.driver.maxResultSize=3g --conf spark.default.parallelism=600 --conf spark.storage.memoryFraction=0.5 --conf spark.network.timeout=360s --conf spark.shuffle.memoryFraction=0.4 --conf spark.yarn.executor.memoryOverhead=4096 --conf spark.ui.port=0 --conf "spark.ui.filters=" --queue root.bdoc.huawei_wzjd_kafka --num-executors 50 --executor-memory 16G --executor-cores 2 --driver-memory 8G --jars /home/huawei_wzjd_kafka/json4s-native_2.11-3.2.11.jar,/home/huawei_wzjd_kafka/MiddleScreen/myjars/spark-hbaseV2_2.11-2.3.2.jar,/home/huawei_wzjd_kafka/MiddleScreen/jedis-3.2.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/mysql-connector-java-5.1.47.jar,/home/huawei_wzjd_kafka/MiddleScreen/commons-pool2-2.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/spark-redis_2.11-2.4.2.jar,/home/huawei_wzjd_kafka/fastjson-1.2.8.jar --principal huawei_wzjd_kafka@WZJDH --keytab huawei_wzjd_kafka.keytab --queue root.bdoc.huawei_wzjd_kafka --conf spark.storage.memoryFraction=0.5 --conf spark.network.timeout=360s --conf spark.shuffle.memoryFraction=0.4 --conf spark.yarn.executor.memoryOverhead=4096 --conf spark.ui.port=0 --conf "spark.ui.filters=" /home/huawei_wzjd_kafka/GlobalHeatMap.jar "10.252.31.100" "22400" "jdbc:mysql://10.252.30.208:3306/DWA_WZMF" "wzmf_monitor" "WZ!0604mfor"


<br /> 
##执行参数
参数1：redisHost <br />
参数2：redisPort <br />
参数3：mysql的jdbc <br />
参数4：mysql的账号 <br />
参数5：mysql的密码 <br />
##部署后业务机服务器目录结构



##V1.0.0 版本内容更新
* 从redis中获取任务0_heat ,运行中状态为1_heat ，运行完成后2_heat <br />
* 从redis中获取任务根据县，市，省在mysql中取出我们需要的字段 <br />
* 通过mysql中取出的cgi_id进过md5 和拼接成hbase：DWV_WZMF:t_crowd_data表中的rowkey，粒度到小时<br /> 
* 然后统计每个基站经纬度的数量，并进行由大到小的排序  <br />
* 输出到redis中<br />