##执行命令
spark-submit --master yarn --deploy-mode client --principal huawei_wzjd_kafka --keytab huawei_wzjd_kafka.keytab --conf spark.redis.timeout="100000" --conf "spark.driver.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --conf "spark.executor.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --files ./MiddleScreen/conf/spark_jaas.conf,spark_kafka.keytab --conf "spark.driver.extraJavaOptions=-Djava.security.auth.login.config=./MiddleScreen/conf/kafka_client_jaas.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=./spark_jaas.conf" --conf spark.driver.maxResultSize=3g --conf spark.default.parallelism=100 --conf spark.storage.memoryFraction=0.5 --conf spark.network.timeout=360s --conf spark.shuffle.memoryFraction=0.4 --conf spark.yarn.executor.memoryOverhead=4096 --conf spark.ui.port=0 --conf "spark.ui.filters=" --queue root.bdoc.huawei_wzjd_kafka --num-executors 20 --executor-memory 16G --executor-cores 2 --driver-memory 20G --jars ./MiddleScreen/myjars/kafka-clients-0.10.1.1.jar,./MiddleScreen/myjars/kafka_2.10-0.10.1.1.jar,./MiddleScreen/myjars/spark-streaming-kafka-0-10_2.11-2.1.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/myjars/spark-hbaseV2_2.11-2.3.2.jar,/home/huawei_wzjd_kafka/MiddleScreen/mysql-connector-java-5.1.47.jar,/home/huawei_wzjd_kafka/MiddleScreen/commons-pool2-2.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/spark-redis_2.11-2.4.2.jar,/home/huawei_wzjd_kafka/MiddleScreen/jedis-3.2.0.jar,/home/huawei_wzjd_kafka/fastjson-1.2.8.jar,/home/huawei_wzjd_kafka/json4s-native_2.11-3.2.11.jar --class com.huawei.bigdata.spark.ms.DayProvinceCrowds /home/huawei_wzjd_kafka/DayProvinceCrowds.jar 10.252.31.100 22400 1 20200825 DWV_WZMF:t_crowd_data

##执行参数
参数1：redisHost <br />
参数2：redisPort <br />
参数3：选择人留在那个城市的方式  0 是按累计时间排序最多的一个 ，1 按人在最后时间的一个 <br />
参数4：时间粒度到天，是hdfs路劲的一个目录 hdfs://ns2/Intermediate/ODS/TO_D_EVNT_NS_PROV_IMSI_MAP/"+time+"/" <br />
参数5：读取的hbase的表：数据源 <br />
##部署后业务机服务器目录结构



##V1.0.0 版本内容更新
* 从hbase表DWV_WZMF:t_crowd_data 读数据 <br />
* 通过给的参数0 或者1 来确定我们选择的是按时长还是按累计时间得到的人 <br /> 
* 将imsi输出到hdfs的目录 hdfs://ns2/Intermediate/ODS/TO_D_EVNT_NS_PROV_IMSI_MAP/时间/province/result/  <br />