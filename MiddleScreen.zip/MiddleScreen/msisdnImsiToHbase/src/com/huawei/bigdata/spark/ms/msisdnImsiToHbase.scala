package com.huawei.bigdata.spark.ms
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.{HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.{DataFrame, Row}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.client.Put

/**
  * 从hive中取msisdn和imsi写入hbase
  */
object msisdnImsiToHbase {
    def main(args: Array[String]) {
        val hadoopConf: Configuration = new Configuration();
        val sparkConf = new SparkConf().setAppName("SparkHivetoHbase")
        val sc = new SparkContext(sparkConf)
        val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
        import sqlContext.implicits._
        val mappingDF = sqlContext.sql("select msisdn, imsi from ODS.TO_D_EVNT_NS_POSITION_TRACE_MSISDN_ADD_ENDTIME")
        val mappingRDD = mappingDF.rdd
        val hbaseContext = new HBaseContext(sc, getHbaseConnection)
        hbaseContext.bulkPut[Row](mappingRDD,
            TableName.valueOf("DWV_WZMF:TO_M_EVNT_NS_MSIDN_IMSI_MAPPING"),
            (row) => {
                val msisdn = row.getString(0)
                val imsi = row.getString(1)
                val put = new Put(Bytes.toBytes(msisdn))
                put.addColumn(Bytes.toBytes("imsi"), Bytes.toBytes("imsi"), Bytes.toBytes(imsi))
                put
            })
        sc.stop()
    }

    /**
     * 获取Hbase连接
     *
     * @return
     */
    def getHbaseConnection() =  {
        val conf = HBaseConfiguration.create;
        conf.set("hadoop.security.authentication", "kerberos");
        conf.set("hbase.security.authentication", "kerberos");
        val master_principal = "hbase/_HOST@ZHKDC";
        val regionserver_principal = "hbase/_HOST@ZHKDC";
        val krb5_conf = "/etc/krb5.conf";
        System.setProperty("java.security.krb5.conf", krb5_conf)
        conf.set("hbase.master.kerberos.principal", master_principal)
        conf.set("hbase.regionserver.kerberos.principal", regionserver_principal)
        conf.set("hbase.zookeeper.quorum", "hebsjzx-wzjd-master-28-7,hebsjzx-wzjd-master-28-4,hebsjzx-wzjd-master-28-14")
        conf.set("hbase.zookeeper.property.clientPort", "2181")
        conf.set("zookeeper.znode.parent", "/hbase-secure")
        conf
    }

}
