
##集团上的成功脚本
 spark-submit --master yarn --deploy-mode client --principal huawei_wzjd_kafka --keytab huawei_wzjd_kafka.keytab --conf spark.redis.timeout="100000" --conf "spark.driver.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --conf "spark.executor.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --files ./MiddleScreen/conf/spark_jaas.conf,spark_kafka.keytab --conf "spark.driver.extraJavaOptions=-Djava.security.auth.login.config=./MiddleScreen/conf/kafka_client_jaas.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=./spark_jaas.conf" --conf spark.driver.maxResultSize=3g --conf spark.default.parallelism=100 --conf spark.storage.memoryFraction=0.5 --conf spark.network.timeout=360s --conf spark.shuffle.memoryFraction=0.4 --conf spark.yarn.executor.memoryOverhead=4096 --conf spark.ui.port=0 --conf "spark.ui.filters=" --queue root.bdoc.huawei_wzjd_kafka --num-executors 200 --executor-memory 20G --executor-cores 2 --driver-memory 30G --jars ./MiddleScreen/myjars/kafka-clients-0.10.1.1.jar,/home/huawei_wzjd_kafka/MiddleScreen/json4s-core_2.11-3.2.11.jar,/home/huawei_wzjd_kafka/MiddleScreen/json4s-native_2.11-3.2.11.jar,./MiddleScreen/myjars/kafka_2.10-0.10.1.1.jar,./MiddleScreen/myjars/spark-streaming-kafka-0-10_2.11-2.1.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/myjars/spark-hbaseV2_2.11-2.3.2.jar,/home/huawei_wzjd_kafka/MiddleScreen/mysql-connector-java-5.1.47.jar,/home/huawei_wzjd_kafka/MiddleScreen/commons-pool2-2.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/spark-redis_2.11-2.4.2.jar,/home/huawei_wzjd_kafka/MiddleScreen/jedis-3.2.0.jar,/home/huawei_wzjd_kafka/json4s-native_2.11-3.2.11.jar --class com.huawei.bigdata.spark.ms.FeatureDataToHbase ./FeatureDataToHbase.jar FeatureDataToHbase DWV_WZMF:TO_M_EVNT_NS_MSIDN_IMSI_MAPPING hdfs://ns2/Intermediate/DWV/TV_M_USER_LABLE/201912 hdfs://ns2/Intermediate/DWV/TV_M_USER_APP_LABLE/202005
 
##执行参数
参数1：电话与imsi的映射hbase表 <br />
参数2：hdfs的user表 <br />
参数3：hdfs的app表 <br />



##V1.0.0 版本内容更新
* 从hbase表中拿到电话与imsi的映射关系<br />
* 从hdfs取user的数据 <br />
* 从hdfs取app的数据 <br />
* hbase表与user和app的数据进行join取导数据，输出到hbase表 DWV_WZMF:T_BASE_DATA_LABLE<br />