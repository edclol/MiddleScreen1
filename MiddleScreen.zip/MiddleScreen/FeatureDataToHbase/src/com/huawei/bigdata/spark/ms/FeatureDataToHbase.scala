package com.huawei.bigdata.spark.ms


import org.apache.hadoop.hbase.client.{Put, Scan}
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}
import org.json4s.DefaultFormats
import org.json4s.native.JsonMethods.parse


object FeatureDataToHbase {

    case class AppUse(val zhName: String, val appId: String, val useCount: Integer, val flowSum: Double)

    def main(args: Array[String]): Unit = {
        val sparkConf = new SparkConf().setAppName(args(0))
        val sc = new SparkContext(sparkConf);

        val hbaseName = args(1);
        // val hbaseName = "DWV_WZMF:TO_M_EVNT_NS_MSIDN_IMSI_MAPPING";
        val hbaseContext = new HBaseContext(sc, getHbaseConnection)
        val scan = new Scan()
        val allCrowds = hbaseContext.hbaseRDD(TableName.valueOf(hbaseName), scan)


        val timeStamp = System.currentTimeMillis()
        val iphone_imsi: RDD[(String, String)] = allCrowds.map(crowds => {
            val keyRow = Bytes.toString(crowds._2.getRow);
            val cells = crowds._2.rawCells()
            val imsi = Bytes.toString(CellUtil.cloneValue(cells(0)))
            (keyRow, imsi)
        })


        //val dataInputPath = "/in/data"
        //hdfs://ns2/Intermediate/DWV/TV_M_USER_LABLE/201912
        //val dataInputPathUser = "hdfs://ns2/Intermediate/DWV/TV_M_USER_LABLE/201912"
        val dataInputPathUser = args(2);
        val dataInputRdd_User: RDD[(String, String)] = sc.textFile(dataInputPathUser).map(line => {
            var key: String = null
            key = line.split("€€", -1)(7) //key
            (key, line) //
        }).filter(r => {
            r._1 != "" && r._1 != null && r._1.length > 0
        })

        //val dataInputPathApp = "hdfs://ns2/Intermediate/DWV/TV_M_USER_APP_LABLE/201912";
        val dataInputPathApp = args(3);
        val dataInputRdd_App: RDD[(String, String)] = sc.textFile(dataInputPathApp).map(line => {
            var key: String = ""
            key = line.split("€€", -1)(1) //key
            (key, line) //
        }).filter(r => {
            r._1 != "" && r._1 != null && r._1.length > 0
        })

        //imsi line
        //(ipone,(imsi,line),line)
        val imsi_user_App: RDD[(String, (String, String))] = iphone_imsi.filter(r => {
            r._2 != "" && r._2 != null && r._2.length > 0
        }).join(dataInputRdd_User).join(dataInputRdd_App).map(x => (x._2._1._1, (x._2._1._2, x._2._2)))

        val imsi_user_AppReduce: RDD[(String, (String, String))] = imsi_user_App.reduceByKey((x, y) => x)

        hbaseContext.bulkPut[(String, (String, String))](imsi_user_AppReduce,
            TableName.valueOf("DWV_WZMF:T_BASE_DATA_LABLE"),
            (putRecord) => {
                val put = new Put(Bytes.toBytes(putRecord._1))
                val column = putRecord._2._1.split("€€", -1)
                val columnAPP = putRecord._2._2.split("€€", -1)
                val columnFamily = "crowds";
                // put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IDTY_NUMBER"), timeStamp, Bytes.toBytes(column(0)))
                put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("SEX"), timeStamp, Bytes.toBytes(column(1)))
                put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("AGE"), timeStamp, Bytes.toBytes(column(2)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("MAGE_STATUS"), timeStamp, Bytes.toBytes(column(3)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("EDU"), timeStamp, Bytes.toBytes(column(4)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("OCPN"), timeStamp, Bytes.toBytes(column(5)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("MSISDN_MD5"), timeStamp, Bytes.toBytes(column(6)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("MSISDN"), timeStamp, Bytes.toBytes(column(7)))
                put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("ARPU"), timeStamp, Bytes.toBytes(column(8)))
                put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("COMMUNICATION_CONSUME_LEVEL"), timeStamp, Bytes.toBytes(column(9)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("BRAND_ID"), timeStamp, Bytes.toBytes(column(10)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("GLOBAL_MOBILE_USER_LEVEL"), timeStamp, Bytes.toBytes(column(11)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("USER_STATUS"), timeStamp, Bytes.toBytes(column(12)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("INNET_TIME"), timeStamp, Bytes.toBytes(column(13)))
                put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("MSISDN_BELO_PROV_ID"), timeStamp, Bytes.toBytes(column(14)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("CURRENT_RESIDENCE"), timeStamp, Bytes.toBytes(column(15)))
                put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("USER_STAR"), timeStamp, Bytes.toBytes(column(16)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("REALNAME_FLAG"), timeStamp, Bytes.toBytes(column(17)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("HE_CREDIT_SCORE"), timeStamp, Bytes.toBytes(column(18)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("HAS_ELDER"), timeStamp, Bytes.toBytes(column(19)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("HAS_CHILD"), timeStamp, Bytes.toBytes(column(20)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("HAS_PETS"), timeStamp, Bytes.toBytes(column(21)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("RESIDENCE_PLACE"), timeStamp, Bytes.toBytes(column(22)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("WORK_PLACE"), timeStamp, Bytes.toBytes(column(23)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("TOT_FEE"), timeStamp, Bytes.toBytes(column(24)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("REMAINDER_FEE"), timeStamp, Bytes.toBytes(column(25)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_FREQUENT_DOWN"), timeStamp, Bytes.toBytes(column(26)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("OWE_AMT"), timeStamp, Bytes.toBytes(column(27)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("TOL_TAOCAN_FEE"), timeStamp, Bytes.toBytes(column(28)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("LOCAL_CALL_LEVEL"), timeStamp, Bytes.toBytes(column(29)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("BASE_MONTHLY_FEE_LEVEL"), timeStamp, Bytes.toBytes(column(30)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("VALUE_ADD_FEE_LEVEL"), timeStamp, Bytes.toBytes(column(31)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("VOICE_FEE_LEVEL"), timeStamp, Bytes.toBytes(column(32)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("VALUE_ADD_INCOME_LEVEL"), timeStamp, Bytes.toBytes(column(33)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("DATA_PLANLEVEL"), timeStamp, Bytes.toBytes(column(34)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("DATA_COMMUNICATE_LEVEL"), timeStamp, Bytes.toBytes(column(35)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("TOTAL_VOICE_FEE_LEVEL"), timeStamp, Bytes.toBytes(column(36)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("PTOP_SMS_LEVEL"), timeStamp, Bytes.toBytes(column(37)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS4GUSIM_USER"), timeStamp, Bytes.toBytes(column(38)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS4GUSER"), timeStamp, Bytes.toBytes(column(39)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_PAY_EXTRA_USER"), timeStamp, Bytes.toBytes(column(40)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_DATA_EXCEED_USER"), timeStamp, Bytes.toBytes(column(41)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_COUNTRYSIDE_USER"), timeStamp, Bytes.toBytes(column(42)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_GROUP_PAY"), timeStamp, Bytes.toBytes(column(43)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_GROUP_USER"), timeStamp, Bytes.toBytes(column(44)))
                put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("TERM_BRAND"), timeStamp, Bytes.toBytes(column(45)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("TERM_MDL"), timeStamp, Bytes.toBytes(column(46)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("NTW_TYP"), timeStamp, Bytes.toBytes(column(47)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("MSISDN_USE_TERM_CNT"), timeStamp, Bytes.toBytes(column(48)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("DUALSIM_INNET"), timeStamp, Bytes.toBytes(column(49)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("TERM_TYP"), timeStamp, Bytes.toBytes(column(50)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("FLOW_LEVEL"), timeStamp, Bytes.toBytes(column(51)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("WLAN_FLOW_LEVEL"), timeStamp, Bytes.toBytes(column(52)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("VOICE_CALL_LEVEL"), timeStamp, Bytes.toBytes(column(53)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("SMS_LEVEL"), timeStamp, Bytes.toBytes(column(54)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("MNET_SMS_LEVEL"), timeStamp, Bytes.toBytes(column(55)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("MMS_LEVEL"), timeStamp, Bytes.toBytes(column(56)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_MOBILE_READ_MONTHLY_USER"), timeStamp, Bytes.toBytes(column(57)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_MOBILE_VIDEO_MONTHLY_USER"), timeStamp, Bytes.toBytes(column(58)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_MOBILE_ANIMATION_MONTHLY_USER"), timeStamp, Bytes.toBytes(column(59)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_MUSIC_SENIOR_USER"), timeStamp, Bytes.toBytes(column(60)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_CRBT_USER"), timeStamp, Bytes.toBytes(column(61)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_MIGU_MUSIC_SUPER_USER"), timeStamp, Bytes.toBytes(column(62)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_MMMONTHLY_USER"), timeStamp, Bytes.toBytes(column(63)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_MAIL139_USER"), timeStamp, Bytes.toBytes(column(64)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("MAIL139_ACTIVE_LEVEL"), timeStamp, Bytes.toBytes(column(65)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_MAP_USER"), timeStamp, Bytes.toBytes(column(66)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("MAP_FEE_LEVEL"), timeStamp, Bytes.toBytes(column(67)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("LIFE_SMS_USER"), timeStamp, Bytes.toBytes(column(68)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("LOS_WARN_LVL"), timeStamp, Bytes.toBytes(column(69)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("UNUSUAL_CUSTOMER_LOSS_LEVEL"), timeStamp, Bytes.toBytes(column(70)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("HIGH_VALUE_CUSTOMER_LOSS_LEVEL"), timeStamp, Bytes.toBytes(column(71)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_BUSINESS_EXCEPTION_USER"), timeStamp, Bytes.toBytes(column(72)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_SPAM_MESSAGES_USER"), timeStamp, Bytes.toBytes(column(73)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_CARD_HOLD"), timeStamp, Bytes.toBytes(column(74)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_BAD_DEBT_USER"), timeStamp, Bytes.toBytes(column(75)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_DND_USER"), timeStamp, Bytes.toBytes(column(76)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_4G_MOBILE"), timeStamp, Bytes.toBytes(column(77)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_CAMPUS_USER"), timeStamp, Bytes.toBytes(column(78)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_HOME_BROADBAND"), timeStamp, Bytes.toBytes(column(79)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_ARBITRARILY_SHARE"), timeStamp, Bytes.toBytes(column(80)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_ARBITRARILY_LOOK"), timeStamp, Bytes.toBytes(column(81)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("IS_ARBITRARILY_USE"), timeStamp, Bytes.toBytes(column(82)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("TOTAL_FLOW_FREE"), timeStamp, Bytes.toBytes(column(83)))
                //        put.addColumn(Bytes.toBytes(columnFamily),Bytes.toBytes("LOAD_TM"), timeStamp, Bytes.toBytes(column(84)))


                //app
                //        put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("DATA_TM"), timeStamp, Bytes.toBytes(columnAPP(2)))
                put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("APP_PREFERENCE"), timeStamp, Bytes.toBytes(getAppUseId(columnAPP(3))))
                //        put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("PREFERENCE_MUSIC"), timeStamp, Bytes.toBytes(getAppUseId(columnAPP(4))))
                //        put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("PREFERENCE_CHAT"), timeStamp, Bytes.toBytes(getAppUseId(columnAPP(5))))
                //        put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("PREFERENCE_TOOL"), timeStamp, Bytes.toBytes(getAppUseId(columnAPP(6))))
                //        put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("PREFERENCE_GAME"), timeStamp, Bytes.toBytes(getAppUseId(columnAPP(7))))
                //        put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("PREFERENCE_FINANCE"), timeStamp, Bytes.toBytes(getAppUseId(columnAPP(8))))
                //        put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("CREDIT_CARD_NUM"), timeStamp, Bytes.toBytes(columnAPP(9)))
                //        put.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes("CREDIT_CARD_TYPE"), timeStamp, Bytes.toBytes(getAppUseId(columnAPP(10))))

                put
            })


        sc.stop()
    }

    /**
     * 对JSON数据进行转换并进行排序，得到最大的一个
     *
     * @param str
     * @return
     */
    def getAppUseId(str: String): String = {
        if (!str.equals("\\N")) {
            implicit val formats = DefaultFormats
            val bb: List[AppUse] = parse(str).extract[List[AppUse]];
            //val xx = bb.sortWith((x, y) => x.flowSum.compareTo(y.flowSum) > 0)(0)
            var appArray: String = ""
            var i = 0
            for (bba <- bb) {
                if (i != 0) {
                    appArray += "," + bba.appId + "_" + bba.zhName
                } else {
                    appArray += bba.appId + "_" + bba.zhName
                    i = 1
                }
            }
            appArray + ""
        } else {
            str
        }
    }

    /**
     * 获取Hbase连接
     *
     * @return
     */
    /**
     * 获取Hbase连接
     *
     * @return
     */
    def getHbaseConnection() = {
        val conf = HBaseConfiguration.create;
        conf.set("hadoop.security.authentication", "kerberos");
        conf.set("hbase.security.authentication", "kerberos");
        val master_principal = "hbase/_HOST@ZHKDC";
        val regionserver_principal = "hbase/_HOST@ZHKDC";
        val krb5_conf = "/etc/krb5.conf";
        System.setProperty("java.security.krb5.conf", krb5_conf)
        conf.set("hbase.master.kerberos.principal", master_principal)
        conf.set("hbase.regionserver.kerberos.principal", regionserver_principal)
        conf.set("hbase.zookeeper.quorum", "hebsjzx-wzjd-master-28-7,hebsjzx-wzjd-master-28-4,hebsjzx-wzjd-master-28-14")
        conf.set("hbase.zookeeper.property.clientPort", "2181")
        conf.set("zookeeper.znode.parent", "/hbase-secure")
        conf
    }
}

