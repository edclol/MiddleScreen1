##执行命令
./spark-submit --class com.huawei.bigdata.spark.examples.DayProvinceCrowds --master yarn-client --jars /opt/client/Spark2x/spark/bin/spark-hbaseV2_2.11-2.3.2.jar,/opt/client/Spark2x/spark/jars/json4s-native_2.11-3.2.11.jar,/opt/client/Spark2x/spark/xzj/*.jar DayProvinceCrowds.jar 10.90.181.105  22400  0


##字符串截取说明：
"""
    
    //这个是测试时截取的，正式需要把9改为8，因为测试时，时间戳前面多加了一个下划线
    //示例：b5e8435ba95111ea937ffa163e4b7336340101_lac_ci_2020060814
    val cgiId = keyRow.substring(0, keyRow.length - 9)
    
"""



##jar包说明
    spark-hbaseV2_2.11-2.3.2.jar
    
    spark-redis_2.11-2.4.2.jar
    
    jedis-3.2.0.jar
    
    fastjson-1.2.8.jar
    
    commons-pool2-2.0.jar


##参数说明
###1.args(0):访问redis的url地址

"""
 
    val sc = new SparkContext(new SparkConf()
      .setAppName("GlobalHeatCollection")
      .set("spark.redis.host", args(0))
      .set("spark.redis.port", args(1))
    )

"""

###2.args(1):访问redis的端口
"""
 
    val sc = new SparkContext(new SparkConf()
      .setAppName("GlobalHeatCollection")
      .set("spark.redis.host", args(0))
      .set("spark.redis.port", args(1))
    )

"""

###3.args(2):(summary_type:人员去重方式选择) 0:按驻留时长保留某个人出现的最后位置     1:按出现的最后位置保留某个人的位置
  
  """
      
       if(args(2).equals("0")){//按驻留时长保留某个人出现的最后位置
            CrowdsAnalaysisByStayDate(sc,hbaseContext,scan,broadCastMap)
          }else{//否则就代表1：按出现的最后位置保留某个人的位置
            CrowdsAnalaysisByLastTime(sc,hbaseContext,scan,broadCastMap)
          }
  """



###3.args(3):一般不指定时间执行这个参数不用传，若需要指定时间点执行任务，则必须传此入参（入参格式为：""20200608-20200609" 理解为："开始时间-结束时间"，其中时间格式必须精确到天）

"""
    
    if (args.size >= 3) {
      //如果传入参数，则代表自定义事件去获取统计数据
      //根据入参统计数据并写入HDFS args（3）入参格式设定："20200508-20200508"
      val dates = args(3).split("-");
      val dateStr = DateUtil.dateRegx(dates(0), dates(1))
      strbuf.append(dateStr)
    }
"""