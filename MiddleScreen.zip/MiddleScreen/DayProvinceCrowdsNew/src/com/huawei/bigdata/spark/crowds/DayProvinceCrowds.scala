package com.huawei.bigdata.spark.crowds

import java.text.SimpleDateFormat
import java.util
import java.util.{Calendar, Date}

import com.redislabs.provider.redis._
import org.apache.hadoop.hbase.client.Scan
import org.apache.hadoop.hbase.filter.{CompareFilter, RegexStringComparator, RowFilter}
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.hadoop.io.NullWritable
import org.apache.hadoop.mapred.lib.MultipleTextOutputFormat
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.JavaConverters._
import scala.collection.mutable.ArrayBuffer

object DayProvinceCrowds {
    def main(args: Array[String]): Unit = {
        val Array(output, date, appName) = args
        val sc = new SparkContext(new SparkConf().setAppName(appName))

        //读取当天全国的5分钟切片程序
        val hbaseContext = new HBaseContext(sc, getHbaseConnection())
        val scan = new Scan()
        val filter = new RowFilter(CompareFilter.CompareOp.EQUAL, new RegexStringComparator(".*(" + date + ").*$"))
        scan.setFilter(filter)
        val tableName = "DWV_WZMF:t_crowd_data";
        val allCrowds = hbaseContext.hbaseRDD(TableName.valueOf(tableName), scan)
        val crowds = allCrowds.map(crowds => {
            val keyRow = Bytes.toString(crowds._2.getRow);
            val province = keyRow.split("_", -1)(1);
            val time = keyRow.split("_", -1)(4);
            val cells = crowds._2.rawCells()
            val dayArray = ArrayBuffer[(String, String)]()
            for (cell <- cells) {
                val columnName = Bytes.toString(CellUtil.cloneQualifier(cell))
                //获取对应时间片数据
                val imsi = Bytes.toString(CellUtil.cloneValue(cell))
                val imsiArray = imsi.split(",")
                for (imsi <- imsiArray) {
                    dayArray += new Tuple2(imsi, time + columnName + "_" + province)
                }
            }
            dayArray.toList
        })
        val crowdsFlat: RDD[(String, String)] = crowds.flatMap(x => x)
        val crowdsNew = crowdsFlat.reduceByKey((x, y) => {
            if (x.split("_", -1)(0).toLong > x.split("_", -1)(0).toLong) {
                x
            }
            else {
                y
            }
        }).map(x=>(x._2.split("_",-1)(1),x._1))
        crowdsNew.saveAsHadoopFile("/Intermediate/ODS/TO_D_EVNT_NS_PROV_IMSI_MAP/", classOf[String], classOf[String],
            classOf[RDDMultipleTextOutputFormat])
        sc.stop()
    }
}
class RDDMultipleTextOutputFormat extends MultipleTextOutputFormat[Any, Any] {
    override def generateActualKey(key: Any, value: Any): Any =
        NullWritable.get()

    override def generateFileNameForKeyValue(key: Any, value: Any, name: String): String =
        key.toString + "/" + name
}

