package com.huawei.bigdata.spark.crowds

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

object DateUtil {


 /* def main(args: Array[String]): Unit = {
    println(dateRegx("20200522","20200609"))
  }
*/

  def dateRegx(startDate:String,endDate:String): String ={
    val simpl = new SimpleDateFormat("yyyyMMdd")
    val dateStart = simpl.parse(startDate)
    val dateEnd = simpl.parse(endDate)
    var indexDate = dateStart;
    val datebuffer = new StringBuffer();
    datebuffer.append(simpl.format(indexDate))
    while (indexDate.before(dateEnd)){
      indexDate = nextDay(indexDate)
      datebuffer.append("|").append(simpl.format(indexDate))
    }
    datebuffer.toString
  }



  def nextDay(date:Date):Date =  {
    val calendar = Calendar.getInstance();
    calendar.setTime(date);
    val day = calendar.get(Calendar.DATE);
    calendar.set(Calendar.DATE, day + 1);
    val newDate = calendar.getTime();
    return newDate;
  }

}
