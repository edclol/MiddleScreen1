package com.huawei.bigdata.spark.ms

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.serializer.SerializerFeature
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}
import com.redislabs.provider.redis._
import org.apache.hadoop.fs.{FileSystem}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.collection.mutable

object CrowdMigProvince {
    val provinceMap: Map[String, String] = Map(
        "BJ_mme" -> "110000",
        "SH_mme" -> "310000",
        "TJ_mme" -> "120000",
        "CQ_mme" -> "500000",
        "GZ_mme" -> "520000",
        "HB_mme" -> "420000",
        "SN_mme" -> "610000",
        "HE_mme" -> "130000",
        "HA_mme" -> "410000",
        "AH_mme" -> "340000",
        "FJ_mme" -> "350000",
        "QH_mme" -> "630000",
        "GS_mme" -> "620000",
        "ZJ_mme" -> "330000",
        "HL_mme" -> "230000",
        "JS_mme" -> "320000",
        "JL_mme" -> "220000",
        "NX_mme" -> "640000",
        "SD_mme" -> "370000",
        "SX_mme" -> "140000",
        "XJ_mme" -> "650000",
        "GD_mme" -> "440000",
        "LN_mme" -> "210000",
        "GX_mme" -> "450000",
        "HN_mme" -> "430000",
        "JX_mme" -> "360000",
        "NM_mme" -> "150000",
        "YN_mme" -> "530000",
        "SC_mme" -> "510000",
        "XZ_mme" -> "540000",
        "HI_mme" -> "460000"
    )

    def main(args: Array[String]): Unit = {
        val Array(redisHost, redisPort, url, username, pass, time) = args
        val sc = new SparkContext(new SparkConf()
                .setAppName("CrowdMigProvince" + time)
                .set("spark.redis.host", args(0))
                .set("spark.redis.port", args(1)))

        //先从redis中读取相应的迁移任务的crowid数据
        val redisHashRDD: RDD[(String, String)] = sc.fromRedisHash("t_analy_task_id")

        //2 将redishash中的数据进行重组（mkey，"1_migrate")
        //得到t_migrate_task+主键ID
        val redisMap = redisHashRDD.filter(_._2 == "0_migrate")
                .map(x => {
                    //"t_migrate_task_159799320672818830"
                    val Mkey = "t_migrate_task_" + x._1
                    (Mkey, x._1)
                }).collectAsMap()

        //3 从rdd中循环获取我们要得到的Mkey
        for (rdd <- redisMap) {
            val mkey: String = rdd._1
            val id = rdd._2
            //通过任务id构造id构造的迁移任务id从redis中读取相应的的数据


            val migrateTaskInputRdd: RDD[(String, String)] = sc.fromRedisHash(mkey)
            //val migrateTaskInputRdd: RDD[(String, String)] = sc.fromRedisHash("t_migrate_task_159739467099117747")

            // 将value是ADMIN_PRO的id装进id这个是分析完的，1_migrate
            val idPro_2: mutable.HashMap[String, String] = new mutable.HashMap[String, String]()

            //晒选集合的value是包含ADMIN_PRO的RDD
            val adminFilter_RDD: RDD[(String, String)] = migrateTaskInputRdd.filter(_._2.contains("ADMIN_PRO"))
            //判断是否有任务要处理
            if (!adminFilter_RDD.isEmpty()) {

                //将正在分析的数据0_migrate变成1_migrate
                val RDD_1migrate: RDD[(String, String)] = sc.parallelize(List((id, "1_migrate")))

                sc.toRedisHASH(RDD_1migrate, "t_migrate_task_id")
                sc.toRedisHASH(RDD_1migrate, "t_analy_task_id")

                // 有待处理的 省级任务
                val mt_MAP: collection.Map[String, String] = migrateTaskInputRdd.collectAsMap()

                //每次从redis中循环得出4条数据（crowd_id,region_id,migrate_time,migrate_type）

                val mt_crowd_id_S: String = mt_MAP.get("crowd_id").get
                val mt_region_id_S: String = mt_MAP.get("region_id").get
                val mt_time_S: String = mt_MAP.get("migrate_time").get
                //val migrate_type_S: String = mt_MAP.get("migrate_type").get

                //today路径
                val today_Path: String = getPath(mt_time_S, mt_region_id_S)
                val todayfilePath = new org.apache.hadoop.fs.Path(today_Path)
                val today_System: FileSystem = todayfilePath.getFileSystem(sc.hadoopConfiguration)
                //构建省的map编码
                // 4 todo 来源地和目的地的进行统计
                //来源地的list所有城市的集合
                val sourceresultList = new java.util.ArrayList[Any]()
                val whereresultList = new java.util.ArrayList[Any]()
                //判断是否存在今日的目录
                if (today_System.exists(todayfilePath)) {
                    val provinces: Array[String] = sc.parallelize(provinceMap.toList).map(x => x._2).collect

                    val source_wheretime = getDate(mt_time_S)
                    val today_imsihdfs = sc.textFile(today_Path)
                    //source路径
                    val source_today: String = getPath(source_wheretime._1, mt_region_id_S)
                    //where的路径
                    val where_today: String = getPath(source_wheretime._2, mt_region_id_S)
                    // val where_today: String = getPath(source_wheretime._2,"410000")
                    //判断路劲是否存在
                    val StodayfilePath = new org.apache.hadoop.fs.Path(source_today)
                    val Stoday_System: FileSystem = StodayfilePath.getFileSystem(sc.hadoopConfiguration)
                    val WtodayfilePath = new org.apache.hadoop.fs.Path(where_today)
                    val Wtoday_System: FileSystem = WtodayfilePath.getFileSystem(sc.hadoopConfiguration)


                    val source_whereimsi = if (Stoday_System.exists(StodayfilePath) && Wtoday_System.exists(WtodayfilePath)) {
                        val source_toDayImsi = sc.textFile(source_today)
                        val where_toDayImsi = sc.textFile(where_today)
                        val today_sourceimsi = today_imsihdfs.subtract(source_toDayImsi)
                        val today_whereimsi = today_imsihdfs.subtract(where_toDayImsi)
                        (today_sourceimsi, today_whereimsi)
                    } else if (!Stoday_System.exists(StodayfilePath) && Wtoday_System.exists(WtodayfilePath)) {
                        val where_toDayImsi = sc.textFile(where_today)
                        val today_sourceimsi = today_imsihdfs
                        val today_whereimsi = today_imsihdfs.subtract(where_toDayImsi)
                        (today_sourceimsi, today_whereimsi)
                    } else if (Stoday_System.exists(StodayfilePath) && !Wtoday_System.exists(WtodayfilePath)) {
                        val source_toDayImsi = sc.textFile(source_today)
                        val today_sourceimsi = today_imsihdfs.subtract(source_toDayImsi)
                        val today_whereimsi = today_imsihdfs
                        (today_sourceimsi, today_whereimsi)
                    } else {
                        val today_sourceimsi = today_imsihdfs
                        val today_whereimsi = today_imsihdfs
                        (today_sourceimsi, today_whereimsi)
                    }


                    for (province <- provinces; if mt_region_id_S != province) {

                        //source路径
                        val source_Path: String = getPath(source_wheretime._1, province)
                        //where的路径
                        val where_Path: String = getPath(source_wheretime._2, province)
                        //hdfs的imsi


                        val sourcefilePath = new org.apache.hadoop.fs.Path(source_Path)
                        val wherefilePath = new org.apache.hadoop.fs.Path(where_Path)
                        val source_System: FileSystem = sourcefilePath.getFileSystem(sc.hadoopConfiguration)
                        val where_System: FileSystem = wherefilePath.getFileSystem(sc.hadoopConfiguration)
                        //判断是否有这个路劲
                        var source_All: Long = 0
                        var where_All: Long = 0


                        if (source_System.exists(sourcefilePath) && where_System.exists(wherefilePath)) {
                            val source_imsihdfs = sc.textFile(source_Path)
                            val where_imsihdfs = sc.textFile(where_Path)

                            val source_where = if (mt_crowd_id_S == "0") {
                                val source_imsi = source_imsihdfs.intersection(source_whereimsi._1)
                                //where与mysql交集的imsi
                                val where_imsi = where_imsihdfs.intersection(source_whereimsi._2)
                                (source_imsi, where_imsi)
                            } else {
                                //得到mysql的（imsi，crowdid）的集合
                                val Mysql_Imsi: RDD[String] = getMysql(url, username, pass, mt_crowd_id_S)
                                val source_imsi = source_imsihdfs.intersection(source_whereimsi._1).intersection(Mysql_Imsi)
                                //where与mysql交集的imsi
                                val where_imsi = where_imsihdfs.intersection(source_whereimsi._2).intersection(Mysql_Imsi)

                                (source_imsi, where_imsi)
                            }
                            source_All = source_where._1.count()
                            //hdfs上面的总人数
                            where_All = source_where._2.count()

                        } else if (source_System.exists(sourcefilePath) && !where_System.exists(wherefilePath)) {
                            val source_imsihdfs = sc.textFile(source_Path)
                            //hdfs上面的总人数

                            val sourceImsi = if (mt_crowd_id_S == "0") {
                                val source_imsi = source_imsihdfs.intersection(source_whereimsi._1)
                                //where与mysql交集的imsi
                                source_imsi
                            } else {
                                //得到mysql的（imsi，crowdid）的集合
                                val Mysql_Imsi: RDD[String] = getMysql(url, username, pass, mt_crowd_id_S)
                                val source_imsi = source_imsihdfs.intersection(source_whereimsi._1).intersection(Mysql_Imsi)
                                source_imsi
                            }
                            source_All = sourceImsi.count()
                            where_All = 0
                        } else if (!source_System.exists(sourcefilePath) && where_System.exists(wherefilePath)) {
                            val where_imsihdfs = sc.textFile(where_Path)


                            val whereImsi = if (mt_crowd_id_S == "0") {
                                //where与mysql交集的imsi
                                val where_imsi = where_imsihdfs.intersection(source_whereimsi._2)
                                where_imsi
                            } else {
                                //得到mysql的（imsi，crowdid）的集合
                                val Mysql_Imsi: RDD[String] = getMysql(url, username, pass, mt_crowd_id_S)
                                //where与mysql交集的imsi
                                val where_imsi = where_imsihdfs.intersection(source_whereimsi._2).intersection(Mysql_Imsi)
                                where_imsi
                            }
                            source_All = 0
                            //hdfs上面的总人数
                            where_All = whereImsi.count()
                        } else {
                            source_All = 0
                            where_All = 0
                        }


                        //来源地的map集合
                        val sourceMap = new java.util.HashMap[String, Any]();
                        //下面arraylist的中map要用java.util.HashMap 否则都是判断正确的false true
                        val wheresMap = new java.util.HashMap[String, Any]();
                        if (source_All != 0) {

                            sourceMap.put("admin_code", province.toString)
                            sourceMap.put("person_num", source_All.toString)
                            //百分比不需要保留相应小数点
                            sourceMap.put("percent", (source_All * 100 / source_whereimsi._1.count()).toString)
                            sourceresultList.add(sourceMap)
                        }

                        if (where_All != 0) {
                            //组装集合
                            wheresMap.put("admin_code", province.toString)
                            wheresMap.put("person_num", where_All.toString)
                            //百分比不需要保留相应小数点
                            wheresMap.put("percent", (where_All * 100 / source_whereimsi._2.count()).toString)
                            whereresultList.add(wheresMap)
                        }
                    }
                }

                //对ArrayList进行json字符串转化
                if (!sourceresultList.isEmpty || !whereresultList.isEmpty) {
                    val resultJsonsource = JSON.toJSONString(sourceresultList, SerializerFeature.BeanToArray)
                    val resultsource = sc.parallelize(Array(("sources", resultJsonsource)))
                    sc.toRedisHASH(resultsource, mkey)

                    val resultJsonwhere = JSON.toJSONString(whereresultList, SerializerFeature.BeanToArray)
                    val resultwhere = sc.parallelize(Array(("wheres", resultJsonwhere)))
                    sc.toRedisHASH(resultwhere, mkey)
                    val id_2_migrate: RDD[(String, String)] = sc.parallelize(List((id, "2_migrate")))

                    // sc.toRedisHASH(id_2_migrate, "t_migrate_task_id")
                    sc.toRedisHASH(id_2_migrate, "t_analy_task_id")
                } else {
                    val id_0_migrate: RDD[(String, String)] = sc.parallelize(List((id, "0_migrate")))

                    // sc.toRedisHASH(id_2_migrate, "t_migrate_task_id")
                    sc.toRedisHASH(id_0_migrate, "t_analy_task_id")
                }
            }


        }

        sc.stop()
    }

    def getPath(time: String, province: String) = {
        var path = new StringBuffer()
        val pathProvince: StringBuffer = path.append("hdfs://ns2/Intermediate/ODS/TO_D_EVNT_NS_PROV_IMSI_MAP/") //可以读取下面所有的文件
                .append(time)
                .append("/")
                .append(province)
                .append("/")
                .append("result")
        pathProvince.toString
    }


    def getDate(date: String) = {
        val simpl = new SimpleDateFormat("yyyyMMdd")
        val calendar = Calendar.getInstance();
        val daydate = simpl.parse(date);
        calendar.setTime(daydate)
        val day = calendar.get(Calendar.DATE);
        calendar.set(Calendar.DATE, day - 1)
        val source_migrate = simpl.format(calendar.getTime())
        calendar.set(Calendar.DATE, day + 1)
        val wheres_migrate = simpl.format(calendar.getTime())
        (source_migrate, wheres_migrate)
    }


    /**
     * 获取mysql的数据
     *
     * @param url
     * @param username
     * @param pass
     * @param crowid
     * @return
     */
    def getMysql(url: String, username: String, pass: String, crowid: String) = {
        val spark: SparkSession = SparkSession.builder().appName("CrowdMigProvince").getOrCreate()
        val reader = spark.read.format("jdbc")
                .option("url", url)
                .option("driver", "com.mysql.jdbc.Driver")
                .option("user", username)
                .option("password", pass)
                .option("dbtable", "t_target_personnel")
                .load()

        val df: DataFrame = reader.select("imsi", "crowd_id").where("status=" + "'normal'")
        val rdd: RDD[Row] = df.rdd
        val imsi_id: RDD[String] = rdd.map(row => {
            val imsi = row.getAs[String]("imsi")
            val crowd_id = row.getAs[Long]("crowd_id").toString
            imsi
        })
        imsi_id
    }

}
