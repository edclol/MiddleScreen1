package com.huawei.bigdata.spark.ms

import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import org.apache.hadoop.conf.Configuration
import org.apache.kafka.common.protocol.SecurityProtocol
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.{Seconds, StreamingContext}
import scala.collection.mutable
import org.apache.hadoop.hbase.TableName
import org.apache.spark.SparkConf
import org.apache.hadoop.hbase.client.{Connection, ConnectionFactory, Put, Table}
import org.apache.spark.SparkContext
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.spark.HBaseContext

/*
  <checkPointDir> checkPoint保存目录
  <batchTime> 批次时间
  <brokers> kafka broker地址
  <eTiem> 超时时间
*/

object MSBSCrowdCollect {


    // topic和省编码映射表
    val provinceMap: Map[String, String] = Map(
        "BJ_mme" -> "110000", "BJ_nsmc" -> "110000",
        "SH_mme" -> "310000", "SH_nsmc" -> "310000",
        "TJ_mme" -> "120000", "TJ_nsmc" -> "120000",
        "CQ_mme" -> "500000", "CQ_nsmc" -> "500000",
        "GZ_mme" -> "520000", "GZ_nsmc" -> "520000",
        "HB_mme" -> "420000", "HB_nsmc" -> "420000",
        "SN_mme" -> "610000", "SN_nsmc" -> "610000",
        "HE_mme" -> "130000", "HE_nsmc" -> "130000",
        "HA_mme" -> "410000", "HA_nsmc" -> "410000",
        "AH_mme" -> "340000", "AH_nsmc" -> "340000",
        "FJ_mme" -> "350000", "FJ_nsmc" -> "350000",
        "QH_mme" -> "630000", "QH_nsmc" -> "630000",
        "GS_mme" -> "620000", "GS_nsmc" -> "620000",
        "ZJ_mme" -> "330000", "ZJ_nsmc" -> "330000",
        "HL_mme" -> "230000", "HL_nsmc" -> "230000",
        "JS_mme" -> "320000", "JS_nsmc" -> "320000",
        "JL_mme" -> "220000", "JL_nsmc" -> "220000",
        "NX_mme" -> "640000", "NX_nsmc" -> "640000",
        "SD_mme" -> "370000", "SD_nsmc" -> "370000",
        "SX_mme" -> "140000", "SX_nsmc" -> "140000",
        "XJ_mme" -> "650000", "XJ_nsmc" -> "650000",
        "GD_mme" -> "440000", "GD_nsmc" -> "440000",
        "LN_mme" -> "210000", "LN_nsmc" -> "210000",
        "GX_mme" -> "450000", "GX_nsmc" -> "450000",
        "HN_mme" -> "430000", "HN_nsmc" -> "430000",
        "JX_mme" -> "360000", "JX_nsmc" -> "360000",
        "NM_mme" -> "150000", "NM_nsmc" -> "150000",
        "YN_mme" -> "530000", "YN_nsmc" -> "530000",
        "SC_mme" -> "510000", "SC_nsmc" -> "510000",
        "XZ_mme" -> "540000", "XZ_nsmc" -> "540000",
        "HI_mme" -> "460000", "HI_nsmc" -> "460000"
    )

    def main(args: Array[String]): Unit = {
        val Array(checkPointDir, batchTime, brokers, eTime, topics, hbaseTable,appName,groupid) = args
        val conf: SparkConf = new SparkConf().setAppName(appName)
        val batchDuration = Seconds(batchTime.toInt)
        val expireTime: Long = eTime.toLong

        val sc = new SparkContext(conf)
        val ssc = new StreamingContext(sc, batchDuration)

        ssc.checkpoint(checkPointDir)
        val topicArr = topics.split(",")
        val topicSet: Set[String] = topicArr.toSet

        val kafkaParams = new mutable.HashMap[String, Object]()
        System.setProperty("javax.security.auth.useSubjectCredsOnly", "true")
        System.setProperty("javax.security.krb5.debug", "false")

        kafkaParams.put("bootstrap.servers", brokers)
        kafkaParams.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
        kafkaParams.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer")
        kafkaParams.put("group.id", groupid)
        kafkaParams.put("metadata.broker.list", brokers)
        kafkaParams.put("security.protocol", SecurityProtocol.SASL_PLAINTEXT.name())
        kafkaParams.put("sasl.mechanism", "GSSAPI")
        kafkaParams.put("sasl.kerberos.server.name", "kafka")
        #kafkaParams.put("auto.offset.reset", "latest")

        val locationStrategy = LocationStrategies.PreferConsistent
        val consumerStrategy = ConsumerStrategies.Subscribe[String, String](topicSet, kafkaParams)
        val kafkaStream = KafkaUtils.createDirectStream[String, String](ssc, locationStrategy, consumerStrategy)
        val valueStream = kafkaStream.map(line => (provinceMap.get(line.topic()).get, line.value()))

        // 数据归一化
        val records: DStream[(String, String, String, String, String)] = valueStream.map(getRecord)

        // 过滤无效数据
        // province, imsi, startTime, lac, ci
        val recordsFilter: DStream[(String, String, Long, String, String)] = records.filter(x => {
            var validFlag = true
            if (x._1 == "" || x._2 == "" || x._3 == "" || x._4 == "" || x._5 == "") {
                validFlag = false
            }
            validFlag
        }).map(x => {
            (x._1.trim, x._2.trim, x._3.trim.toLong, x._4.trim, x._5.trim)
        })

        val cores: DStream[(String, (String, Long, String, String))] = recordsFilter.map(x => (x._2, (x._1, x._3, x._4, x._5)))
        val datas: DStream[(String, (String, Long, String, String))] = cores.reduceByKey((x: (String, Long, String, String), y: (String, Long, String, String)) => {
            if (x._2 >= y._2) {
                x
            } else {
                y
            }
        })

        // 失联用户信令补齐
        // 沉默用户超过30分钟清除
        val dataUpdata: DStream[(String, (String, Long, String, String))] = datas.updateStateByKey((newValues: Seq[(String, Long, String, String)], state: Option[(String, Long, String, String)]) => {
            val time: Long = System.currentTimeMillis() / 1000L
            //获取缓存的老数据
            var oldValue: (String, Long, String, String) = state.getOrElse(null)
            var newValue: (String, Long, String, String) = oldValue
            //获取老数据的信令时间
            val oldTime: Long = if (oldValue == null) {
                time
            } else {
                oldValue._2
            }
            //如果新值为空
            if (newValues.size == 0) {
                if (oldValue == null) { //如果老值也为空则删除此用户数据
                    None
                } else {
                    //如果老值不为空
                    if (time - oldTime >= expireTime) {
                        //如果数据超时则删除此用户数据
                        None
                    } else {
                        //不超时则继续输出老数据
                        Option(oldValue)
                    }
                }
            }
            else {
                //如果新值不为空则更新值并输出新值
                for (value <- newValues) {
                    newValue = value
                }
                Option(newValue)
            }
        })
        val dataBytopic: DStream[(String, String)] = dataUpdata.map(x => {
            val workTime: String = new SimpleDateFormat("yyyyMMddHH").format(new Date)
            val key = x._2._1 + "_" + x._2._3 + "_" + x._2._4
            ((getMD5Str(key)+ "_" + key + "_" + workTime), x._1)
        })
        // 根据RowKey聚合数据
        val data_end: DStream[(String, String)] = dataBytopic.reduceByKey(_ + "," + _)
        val hbaseContext = new HBaseContext(sc, getHbaseConfig())
        hbaseContext.streamBulkPut[(String, String)](data_end,
            TableName.valueOf(hbaseTable),
            (putRecord) => {
                val put = new Put(Bytes.toBytes(putRecord._1))
                put.addColumn(Bytes.toBytes("crowds"), Bytes.toBytes(getTime), Bytes.toBytes(putRecord._2))
                put
            })

        ssc.start()
        ssc.awaitTermination()
    }

    /*
        对于kafka的mme,nsmc两种格式的数据归一化为一种数据格式
        数据格式：imsi startTime lac ci province
    */
    def getRecord(line: (String, String)): (String, String, String, String, String) = {
        val elems = line._2.split("\\|", -1)
        val length: Int = elems.length
        // imsi
        val imsi = if (length == 17L) {
            elems(5)
        } else if (length == 13L) {
            elems(8)
        }
        else {
            "0"
        }
        // startTime
        val startTime = if (length == 17L) {
            elems(8)
        } else if (length == 13L) {
            gettiming(elems(0).trim).toString
        } else {
            "0"
        }
        // lac
        val lac = if (length == 17L) {
            elems(12)
        } else if (length == 13L) {
            elems(3)
        }
        else {
            "0"
        }

        // ci
        val ci = if (length == 17L) {
            elems(13)
        } else if (length == 13L) {
            elems(4)
        }
        else {
            "0"
        }
        // province
        // 取kafka中记录的topic作为省
        val province = line._1
        (province, imsi, startTime, lac, ci)
    }

    //获取hbase配置
    def getHbaseConfig(): Configuration = {
        val conf = HBaseConfiguration.create;
        conf.set("hadoop.security.authentication", "kerberos");
        conf.set("hbase.security.authentication", "kerberos");
        val master_principal = "hbase/_HOST@ZHKDC";
        val regionserver_principal = "hbase/_HOST@ZHKDC";
        val krb5_conf = "/etc/krb5.conf";
        System.setProperty("java.security.krb5.conf", krb5_conf)
        conf.set("hbase.master.kerberos.principal", master_principal)
        conf.set("hbase.regionserver.kerberos.principal", regionserver_principal)
        conf.set("hbase.zookeeper.quorum", "hebsjzx-wzjd-master-28-7,hebsjzx-wzjd-master-28-4,hebsjzx-wzjd-master-28-14")
        conf.set("hbase.zookeeper.property.clientPort", "2181")
        conf.set("zookeeper.znode.parent", "/hbase-secure")
        conf
    }

    //获取当前归属5分钟的时间片
    def getTime(): String = {
        val curTime = System.currentTimeMillis()
        val minute = new Date(curTime).getMinutes()
        var time: Int = minute / 5;
        time * 5 + ""
    }

    def gettiming(time: String) = {
        val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val tm = time
        val dt = fm.parse(tm);
        dt.getTime()
    }
    def getMD5Str(key:String): String ={
        val md5 = MessageDigest.getInstance("MD5")
        val md5Bytes = md5.digest(key.getBytes("UTF-8"))
        val bufferMd5 = new StringBuffer();
        for (i <- 0 to (md5Bytes.length-1)) {
            val in =  md5Bytes(i) & 0xff;
            if (in < 16) {
                bufferMd5.append("0")
            }
            bufferMd5.append(Integer.toHexString(in))
        }
        bufferMd5.toString()
    }
}
