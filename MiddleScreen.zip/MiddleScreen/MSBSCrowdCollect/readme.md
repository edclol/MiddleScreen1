#位置中屏系统
##5分钟基站人群明细分析
<br />

##运行环境
####华为
spark-submit --master yarn --deploy-mode client --principal bbit --keytab /opt/hadoopclient/user.keytab --jars /opt/hadoopclient/zwb/spark2xlib/kafka-clients-0.10.0.0.jar,/opt/hadoopclient/zwb/spark2xlib/kafka_2.10-0.10.0.0.jar,/opt/hadoopclient/zwb/spark2xlib/spark-streaming-kafka-0-10_2.11-2.1.0.jar,/opt/hadoopclient/Spark2xNew/spark/bin/spark-hbaseV2_2.11-2.3.2.jar --class com.huawei.bigdata.spark.ms.MSBSCrowdCollect MSBSCrowdCollect.jar /datastore/li/tmp_for_spark_checkpoint 60 10.90.181.113:21005 120 "SH_mme,BJ_mme" "t_crowd_data" MSBSCrowdCollect
####集团
spark-submit --master yarn --deploy-mode client --principal huawei_wzjd_kafka --keytab huawei_wzjd_kafka.keytab --conf "spark.driver.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --conf "spark.executor.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --files ./MiddleScreen/conf/spark_jaas.conf,spark_kafka.keytab --conf "spark.driver.extraJavaOptions=-Djava.security.auth.login.config=./MiddleScreen/conf/kafka_client_jaas.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=./spark_jaas.conf" --conf spark.driver.maxResultSize=3g --conf spark.default.parallelism=600 --conf spark.storage.memoryFraction=0.5 --conf spark.network.timeout=360s --conf spark.shuffle.memoryFraction=0.4 --conf spark.yarn.executor.memoryOverhead=4096 --conf spark.ui.port=0 --conf "spark.ui.filters=" --queue root.bdoc.huawei_wzjd_kafka  --num-executors 80 --executor-memory 16G --executor-cores 2 --driver-memory 10G --jars ./MiddleScreen/myjars/kafka-clients-0.10.1.1.jar,./MiddleScreen/myjars/kafka_2.10-0.10.1.1.jar,./MiddleScreen/myjars/spark-streaming-kafka-0-10_2.11-2.1.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/myjars/spark-hbaseV2_2.11-2.3.2.jar --class com.huawei.bigdata.spark.ms.MSBSCrowdCollect ./MSBSCrowdCollect.jar /tmp/MiddleScreen/checkpoint_110000 120 10.252.30.154:6667 240 "BJ_mme" DWV_WZMF:t_crowd_data MSBSCrowdCollect_110000_BJ_mme BJ
参数1：checkPoint保存目录<br />
参数2：批次周期时间（默认5分钟）<br />
参数3：kafka broker地址<br />
参数4：超时时间（默认30分钟）<br />
参数5：需要读取的topic <br />
参数6：hbase配置文件路径<br />
参数7：appname<br />
参数8：kafka的groupid<br />
##部署后业务机服务器目录结构 
/readme.md &emsp; 帮助<br />
/pom.xml  &emsp;  编译文件<br />
/src/com/huawei/bigdata/spark/ms/MSBSCrowdCollect.scala  &emsp;  主流程文件<br />
<br />


##V1.0.0 版本内容更新
* 从kafka定时抽取全国31个省的信令数据<br />
* MEE和MC两张格式数据进行归一化处理<br />
* 过滤无效数据<br />
* 转换为KEY(IMSI)VALUE格式<br />
* 同一个批次对于同一个用户只输出最后一个位置数据（按照时间顺序排重）<br />
* 失联用户信令补齐<br />
* 沉默用户超过30分钟清除<br />
* 按基站分组汇总<br />
* 按照省份分表入库，每5分钟分列保存<br />






