package com.huawei.bigdata.spark.ms

import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client.{Get, Put, Result}
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}


object MSSnapshotDetailsM {
    def main(args: Array[String]): Unit = {
        if (args.length != 5) {
            println("MSSnapshotDetails {tableName1} {tableName2} {ip} {port} are missing argument")
            return
        }


        //读取hbase表名
        val tableName1 = args(0)
        //写入hbase表名
        val tableName2 = args(1)
        //redis的ip地址
        val ip = args(2)
        //redis的端口号
        val port = args(3)
        val date_minute = args(4)


        val sparkConf = new SparkConf().setAppName("MSSnapshotDetails " + tableName1 + date_minute).set("spark.redis.host", ip).set("spark.redis.port", port)
        val sc = new SparkContext(sparkConf)

        val spark = SparkSession.builder().appName("MSSnapshotDetails " + tableName1)
                .config("spark.redis.host", ip)
                .config("spark.redis.port", port)
                .getOrCreate()


        import com.redislabs.provider.redis._

        try {
            //获取区域与基站映射数据<AreaId,bsId1,bsId2......>
            val areas = sc.fromRedisHash("area_cell")
            //获取基站与经纬度关系数据<bsid,lat,lng>
            val bs_lat_lng = sc.fromRedisHash("cell_lat_lng")
            //获取当前时间,往前推一小时分钟
            //val date=new Date().getTime-3600000
            val date: Date = new SimpleDateFormat("yyyyMMddHHmm").parse(date_minute)

            val hour = date_minute.substring(0, date_minute.size - 2)

            val minute = getMinutes(date.getTime)

            //精确到小时


            //获取基站id,拼接查询hbase中五分钟基站人群明细表的rowkey：md5+基站id+时间
            val bsidRdd = areas.flatMap(t => t._2.split(",", -1)).map(x => {
                val md5 = getMD5Str(x)
                md5 + "_" + x + "_" + hour
            })


            //获取区域id和基站id的一一对应关系 (bsId,areaId)
            val area_bs = areas.flatMap(t => {
                val areaid = t._1
                val array = t._2.split(",", -1)
                val arr = new Array[(String, String)](array.size)
                for (i <- 0 until array.size) {
                    arr(i) = (array(i), areaid)
                }
                arr
            })

            //创建hbase上下文
            val conf = HBaseConfiguration.create()
            val hbaseContext = new HBaseContext(sc, getHbaseConfig())

            //获取五分钟基站人群明细数据(基站id,imsi),并过滤空数据
            val bsAndImsiRdd = hbaseContext.bulkGet[String, (String, String)](
                TableName.valueOf(tableName1),
                61200,
                bsidRdd,
                record => {
                    new Get(Bytes.toBytes(record)) //record？
                },
                (result: Result) => {
                    /* val curTime = System.currentTimeMillis() - 3600000;
                     val newtime= getMinutes(curTime)*/
                    //获取rowkey
                    val rowkey = Bytes.toString(result.getRow)
                    var cgiid: String = null
                    var imsi: String = null
                    if (rowkey != null) {
                        //切割rowkey，获取基站id
                        cgiid = rowkey.split("_")(1) + "_" + rowkey.split("_")(2) + "_" + rowkey.split("_")(3)
                        //获取列集合
                        val cells = result.rawCells()
                        for (cell <- cells) {
                            //获取列名
                            val q = Bytes.toString(CellUtil.cloneQualifier(cell))
                            //获取对应时间片数据
                            if (q.equals(minute)) {
                                imsi = Bytes.toString(CellUtil.cloneValue(cell))
                            }
                        }
                    }
                    (cgiid, imsi)
                }).filter(t => t._2 != null)


            //按基站id合并三个RDD:bs_lat_lng，bsAndImsiRdd，area_bs数据,生成RDD[(基站id,((imsi,经纬度),区域id))]
            val joinRdd: RDD[(String, ((String, String), String))] = bsAndImsiRdd.join(bs_lat_lng).join(area_bs)

            //对合并的joiRdd数据处理,生成写入hbase的(rowkey:区域id+时间,"crowds",column:基站id+经纬度,value:imsi)
            val resultRdd = joinRdd.map(t => (t._2._2 + "_" + hour + minute, "crowds", t._1 + "+" + t._2._1._2, t._2._1._1))



            //写入hbase数据
            hbaseContext.bulkPut[(String, String, String, String)](resultRdd,
                TableName.valueOf(tableName2),
                (putRecord) => {
                    //putRecord=(rowkey,"crowds",column,value)
                    val put = new Put(Bytes.toBytes(putRecord._1))
                    put.addColumn(Bytes.toBytes(putRecord._2), Bytes.toBytes(putRecord._3), Bytes.toBytes(putRecord._4))
                    put
                })


        } finally {
            sc.stop()
        }

    }

    //转MD5方法
    def getMD5Str(key: String): String = {
        val md5 = MessageDigest.getInstance("MD5")
        val md5Bytes = md5.digest(key.getBytes("UTF-8"))
        val bufferMd5 = new StringBuffer();
        for (i <- 0 to (md5Bytes.length - 1)) {
            val in = md5Bytes(i) & 0xff;
            if (in < 16) {
                bufferMd5.append("0")
            }
            bufferMd5.append(Integer.toHexString(in))
        }
        bufferMd5.toString()
    }

    //获取hbase配置
    def getHbaseConfig(): Configuration = {
        val conf = HBaseConfiguration.create;
        conf.set("hadoop.security.authentication", "kerberos");
        conf.set("hbase.security.authentication", "kerberos");
        val master_principal = "hbase/_HOST@ZHKDC";
        val regionserver_principal = "hbase/_HOST@ZHKDC";
        val krb5_conf = "/etc/krb5.conf";
        System.setProperty("java.security.krb5.conf", krb5_conf)
        conf.set("hbase.master.kerberos.principal", master_principal)
        conf.set("hbase.regionserver.kerberos.principal", regionserver_principal)
        conf.set("hbase.zookeeper.quorum", "hebsjzx-wzjd-master-28-7,hebsjzx-wzjd-master-28-4,hebsjzx-wzjd-master-28-14")
        conf.set("hbase.zookeeper.property.clientPort", "2181")
        conf.set("zookeeper.znode.parent", "/hbase-secure")
        conf
    }

    def getMinutes(curTime: Long) = {
        val minute = new Date(curTime).getMinutes();
        var time: Int = minute / 5;
        val newtime = time * 5 + "";
        newtime
    }
}
