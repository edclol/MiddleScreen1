## 1.执行命令
/usr/lib/spark/bin/spark-submit --class com.huawei.bigdata.spark.ms.CrowdMigDesCity --master yarn --deploy-mode client --principal huawei_wzjd_kafka --keytab huawei_wzjd_kafka.keytab --conf "spark.driver.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar"  --conf "spark.executor.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --files ./MiddleScreen/conf/spark_jaas.conf,spark_kafka.keytab --conf "spark.driver.extraJavaOptions=-Djava.security.auth.login.config=./MiddleScreen/conf/kafka_client_jaas.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=./spark_jaas.conf" --conf spark.driver.maxResultSize=3g --conf spark.default.parallelism=600 --conf spark.storage.memoryFraction=0.5 --conf spark.network.timeout=360s --conf spark.shuffle.memoryFraction=0.4 --conf spark.yarn.executor.memoryOverhead=4096 --conf spark.ui.port=0 --conf "spark.ui.filters=" --queue root.bdoc.huawei_wzjd_kafka --num-executors 30 --executor-memory 20G --executor-cores 2 --driver-memory 30G --jars /home/huawei_wzjd_kafka/json4s-native_2.11-3.2.11.jar,/home/huawei_wzjd_kafka/MiddleScreen/myjars/spark-hbaseV2_2.11-2.3.2.jar,/home/huawei_wzjd_kafka/MiddleScreen/jedis-3.2.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/mysql-connector-java-5.1.47.jar,/home/huawei_wzjd_kafka/MiddleScreen/commons-pool2-2.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/spark-redis_2.11-2.4.2.jar,/home/huawei_wzjd_kafka/fastjson-1.2.8.jar --principal huawei_wzjd_kafka@WZJDH --keytab huawei_wzjd_kafka.keytab --queue root.bdoc.huawei_wzjd_kafka --conf spark.storage.memoryFraction=0.5 --conf spark.network.timeout=360s --conf spark.shuffle.memoryFraction=0.4 --conf spark.yarn.executor.memoryOverhead=4096 --conf spark.ui.port=0 --conf "spark.ui.filters=" /home/huawei_wzjd_kafka/CrowdMigDesCity.jar "10.252.31.100" "22400" "jdbc:mysql://10.252.30.208:3306/DWA_WZMF" "wzmf_monitor" "WZ!0604mfor" 20200825
###说明：以上命令是测试命令，其中只放了redis的相关参数，未放入mysql的相关参数
<br /> 
##执行参数
参数1：redisHost <br />
参数2：redisPort <br />
参数3：mysql的jdbc <br />
参数4：mysql的账号 <br />
参数5：mysql的密码 <br />
参数6：程序运行的appname的时间  <br />
##部署后业务机服务器目录结构



##V1.0.0 版本内容更新
* 从redis中获取任务0_mirgate ,运行中状态为1_mirgate ，运行完成后2_mirgate <br />
* 通过拼接从hdfs获取每个城市的人的imsi 与前一天，后一天的每个hdfs下面的目录进行交集求出迁徙的人<br /> 
* hdfs的目录 hdfs://ns2/Intermediate/ODS/TO_H_EVNT_NS_PROV_IMSI_MAP/时间/city/result/  <br />
* 统计人数，将来源与去向进行统计存入redis中<br />