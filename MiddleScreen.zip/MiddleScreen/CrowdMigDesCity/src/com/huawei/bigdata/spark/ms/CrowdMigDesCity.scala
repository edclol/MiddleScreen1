package com.huawei.bigdata.spark.ms

import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.serializer.SerializerFeature
import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}
import com.redislabs.provider.redis._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.hadoop.hbase.client.Scan
import org.apache.hadoop.hbase.filter.{RegexStringComparator, RowFilter}
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.hadoop.hbase.util.Bytes
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object CrowdMigDesCity {

    def main(args: Array[String]): Unit = {
        val Array(redisHost, redisPort, url, username, pass, time) = args
        val sc = new SparkContext(new SparkConf()
                .setAppName("CrowdMigDesCity" + time)
                .set("spark.redis.host", args(0))
                .set("spark.redis.port", args(1)))

        //先从redis中读取相应的迁移任务的crowid数据
        val redisHashRDD: RDD[(String, String)] = sc.fromRedisHash("t_analy_task_id")

        //2 将redishash中的数据进行重组（mkey，"1_migrate")
        //得到t_migrate_task+主键ID
        val redisMap = redisHashRDD.filter(_._2 == "0_migrate")
                .map(x => {
                    //"t_migrate_task_159817483855414598"
                    val Mkey = "t_migrate_task_" + x._1
                    (Mkey, x._1)
                }).collectAsMap()

        //3 从rdd中循环获取我们要得到的Mkey
        for (rdd <- redisMap) {
            val mkey: String = rdd._1
            val id = rdd._2
            //通过任务id构造id构造的迁移任务id从redis中读取相应的的数据


            val migrateTaskInputRdd: RDD[(String, String)] = sc.fromRedisHash(mkey)
            //val migrateTaskInputRdd: RDD[(String, String)] = sc.fromRedisHash("t_migrate_task_159817483855414598")

            // 将value是ADMIN_PRO的id装进id这个是分析完的，1_migrate
            val idPro_2: mutable.HashMap[String, String] = new mutable.HashMap[String, String]()

            //晒选集合的value是包含TARGET_CITY的RDD
            val adminFilter_RDD: RDD[(String, String)] = migrateTaskInputRdd.filter(_._2.contains("TARGET_CITY"))
            //判断是否有任务要处理
            if (!adminFilter_RDD.isEmpty()) {

                //将正在分析的数据0_migrate变成1_migrate
                val RDD_1migrate: RDD[(String, String)] = sc.parallelize(List((id, "1_migrate")))

                // sc.toRedisHASH(RDD_1migrate, "t_migrate_task_id")
                sc.toRedisHASH(RDD_1migrate, "t_analy_task_id")

                // 有待处理的 省级任务
                val mt_MAP: collection.Map[String, String] = migrateTaskInputRdd.collectAsMap()

                //每次从redis中循环得出4条数据（crowd_id,region_id,migrate_time,migrate_type）

                val mt_crowd_id_S: String = mt_MAP.get("crowd_id").get
                val mt_region_id_S: String = mt_MAP.get("region_id").get
                var mt_time_S: String = mt_MAP.get("migrate_time").get
               // val migrate_type_S: String = mt_MAP.get("migrate_type").get


                if (mt_time_S.length == 8) {
                    mt_time_S = mt_time_S + "12"
                }

                val hbaseParam = mt_region_id_S + "_" + mt_time_S; //city+时间
                //从得到的区域取到imsi
                val hbase_imsi = readCrowdsFromRedis(sc, hbaseParam)
                //取到所有的城市
                val redis_city: RDD[String] = sc.fromRedisHash("cell_city").map(x => x._2).distinct()
                //构建省的map编码
                // 4 todo 来源地和目的地的进行统计
                //来源地的list所有城市的集合
                val sourceresultList = new java.util.ArrayList[java.util.HashMap[String, String]]()
                val whereresultList = new java.util.ArrayList[java.util.HashMap[String, String]]()
                var sourcetoday_All: Long = 0
                var wheretoday_All: Long = 0
                //判断hbase数据是否为空
                if (!hbase_imsi.isEmpty()) {
                    val citys: Array[String] = redis_city.collect

                    val source_wheretime = getDate(mt_time_S)

                    for (city <- citys) {

                        //source路径
                        val source_Path: String = getPath(source_wheretime._1, city)
                        //where的路径
                        val where_Path: String = getPath(source_wheretime._2, city)
                        //判断是否有这个路劲
                        val sourcefilePath = new org.apache.hadoop.fs.Path(source_Path)
                        val wherefilePath = new org.apache.hadoop.fs.Path(where_Path)
                        val source_System: FileSystem = sourcefilePath.getFileSystem(sc.hadoopConfiguration)
                        val where_System: FileSystem = wherefilePath.getFileSystem(sc.hadoopConfiguration)

                        var source_All: Long = 0
                        var where_All: Long = 0


                        if (source_System.exists(sourcefilePath) && where_System.exists(wherefilePath)) {
                            val source_imsihdfs = sc.textFile(source_Path)
                            val where_imsihdfs = sc.textFile(where_Path)

                            val source_where = if (mt_crowd_id_S == "0") {
                                val source_imsi = source_imsihdfs.intersection(hbase_imsi)
                                //where与mysql交集的imsi
                                val where_imsi = where_imsihdfs.intersection(hbase_imsi)
                                (source_imsi, where_imsi)
                            } else {
                                //得到mysql的（imsi，crowdid）的集合
                                val Mysql_Imsi: RDD[String] = getMysql(url, username, pass, mt_crowd_id_S)
                                val source_imsi = source_imsihdfs.intersection(hbase_imsi).intersection(Mysql_Imsi)
                                //where与mysql交集的imsi
                                val where_imsi = where_imsihdfs.intersection(hbase_imsi).intersection(Mysql_Imsi)
                                (source_imsi, where_imsi)
                            }
                            source_All = source_where._1.count()
                            //hdfs上面的总人数
                            where_All = source_where._2.count()

                        } else if (source_System.exists(sourcefilePath) && !where_System.exists(wherefilePath)) {
                            val source_imsihdfs = sc.textFile(source_Path)
                            //hdfs上面的总人数
                            val sourceImsi = if (mt_crowd_id_S == "0") {
                                val source_imsi = source_imsihdfs.intersection(hbase_imsi)
                                //where与mysql交集的imsi
                                source_imsi
                            } else {
                                //得到mysql的（imsi，crowdid）的集合
                                val Mysql_Imsi: RDD[String] = getMysql(url, username, pass, mt_crowd_id_S)
                                val source_imsi = source_imsihdfs.intersection(hbase_imsi).intersection(Mysql_Imsi)
                                source_imsi
                            }
                            source_All = sourceImsi.count()
                            where_All = 0
                        } else if (!source_System.exists(sourcefilePath) && where_System.exists(wherefilePath)) {
                            val where_imsihdfs = sc.textFile(where_Path)


                            val whereImsi = if (mt_crowd_id_S == "0") {
                                //where与mysql交集的imsi
                                val where_imsi = where_imsihdfs.intersection(hbase_imsi)
                                where_imsi
                            } else {
                                //得到mysql的（imsi，crowdid）的集合
                                val Mysql_Imsi: RDD[String] = getMysql(url, username, pass, mt_crowd_id_S)
                                //where与mysql交集的imsi
                                val where_imsi = where_imsihdfs.intersection(hbase_imsi).intersection(Mysql_Imsi)
                                where_imsi
                            }
                            source_All = 0
                            //hdfs上面的总人数
                            where_All = whereImsi.count()
                        } else {
                            source_All = 0
                            where_All = 0
                        }

                        sourcetoday_All += source_All
                        wheretoday_All += where_All

                        //来源地的map集合
                        val sourceMap = new java.util.HashMap[String, String]();
                        //下面arraylist的中map要用java.util.HashMap 否则都是判断正确的false true
                        val wheresMap = new java.util.HashMap[String, String]();
                        if (source_All != 0) {
                            sourceMap.put("admin_code", city + "")
                            sourceMap.put("person_num", source_All + "")
                            //百分比不需要保留相应小数点
                            sourceMap.put("percent", source_All * 100 + "")
                            sourceresultList.add(sourceMap)
                        }

                        if (where_All != 0) {
                            //组装集合
                            wheresMap.put("admin_code", city + "")
                            wheresMap.put("person_num", where_All + "")
                            //百分比不需要保留相应小数点
                            wheresMap.put("percent", where_All * 100 + "")
                            whereresultList.add(wheresMap)
                        }
                    }
                }

                //来源求百分比
                if (!sourceresultList.isEmpty) {
                    for (i <- 0 to sourceresultList.size() - 1) {
                        val source_percent = sourceresultList.get(i).get("percent").toLong / sourcetoday_All
                        sourceresultList.get(i).put("percent", source_percent + "")
                    }
                }

                //来源求百分比
                if (!whereresultList.isEmpty) {
                    for (i <- 0 to whereresultList.size() - 1) {
                        val where_percent = whereresultList.get(i).get("percent").toLong / wheretoday_All
                        whereresultList.get(i).put("percent", where_percent + "")
                    }
                }



                //对ArrayList进行json字符串转化

                if (!sourceresultList.isEmpty || !whereresultList.isEmpty) {
                    val resultJsonsource = JSON.toJSONString(sourceresultList, SerializerFeature.BeanToArray)
                    val resultsource = sc.parallelize(Array(("sources", resultJsonsource)))
                    sc.toRedisHASH(resultsource, mkey)

                    val resultJsonwhere = JSON.toJSONString(whereresultList, SerializerFeature.BeanToArray)
                    val resultwhere = sc.parallelize(Array(("wheres", resultJsonwhere)))
                    sc.toRedisHASH(resultwhere, mkey)
                    val id_2_migrate: RDD[(String, String)] = sc.parallelize(List((id, "2_migrate")))

                    // sc.toRedisHASH(id_2_migrate, "t_migrate_task_id")
                    sc.toRedisHASH(id_2_migrate, "t_analy_task_id")
                } else {
                    val id_0_migrate: RDD[(String, String)] = sc.parallelize(List((id, "0_migrate")))

                    // sc.toRedisHASH(id_2_migrate, "t_migrate_task_id")
                    sc.toRedisHASH(id_0_migrate, "t_analy_task_id")
                }
            }


        }

        sc.stop()
    }

    def getPath(time: String, city: String) = {
        var path = new StringBuffer()
        val pathProvince: StringBuffer = path.append("hdfs://ns2/Intermediate/ODS/TO_H_EVNT_NS_PROV_IMSI_MAP/") //可以读取下面所有的文件
                .append(time)
                .append("/")
                .append(city)
                .append("/")
                .append("result")
        pathProvince + ""
    }


    def getDate(date: String) = {
        val simpl = new SimpleDateFormat("yyyyMMddHH")
        val calendar = Calendar.getInstance();
        val daydate = simpl.parse(date);
        calendar.setTime(daydate)
        val hour = calendar.get(Calendar.HOUR_OF_DAY);
        calendar.set(Calendar.HOUR_OF_DAY, hour - 1)
        val source_migrate = simpl.format(calendar.getTime())
        calendar.set(Calendar.HOUR_OF_DAY, hour + 1)
        val wheres_migrate = simpl.format(calendar.getTime())
        (source_migrate, wheres_migrate)

    }

    /**
     * 获取mysql的数据
     *
     * @param url
     * @param username
     * @param pass
     * @param crowid
     * @return
     */
    def getMysql(url: String, username: String, pass: String, crowid: String) = {
        val spark: SparkSession = SparkSession.builder().appName("CrowdMigDesCity").getOrCreate()
        val reader = spark.read.format("jdbc")
                .option("url", url)
                .option("driver", "com.mysql.jdbc.Driver")
                .option("user", username)
                .option("password", pass)
                .option("dbtable", "t_target_personnel")
                .load()

        val df: DataFrame = reader.select("imsi", "crowd_id").where("status=" + "'normal'")
        val rdd: RDD[Row] = df.rdd
        val imsi_id: RDD[String] = rdd.map(row => {
            val imsi = row.getAs[String]("imsi")
            val crowd_id = row.getAs[Long]("crowd_id") + ""
            (imsi, crowd_id)
        }).filter(x => x._2 == crowid).map(x => x._1)
        imsi_id
    }

    /**
     * 查询快照明细区域人员表（1小时级别）HBase存储
     *
     * @param sc
     * @param rowLike
     * @return
     */
    def readCrowdsFromRedis(sc: SparkContext, rowLike: String): RDD[String] = {
        val hbaseContext = new HBaseContext(sc, getHbaseConfig())
        val tableName = "DWV_WZMF:TO_H_EVNT_NS_AREA_IMSI"; // 208991811585179648_202007311424,110000_4432_20045570+40.08913
        val columnFamily = "crowds"; //area_cell 208991811585179648   ，10000_4432_20045581,110000_4432_23521993,
        val scan = new Scan(); //210000_16583_56008474，   42.94269,124.08813
        import org.apache.hadoop.hbase.filter.CompareFilter
        val filter = new RowFilter(CompareFilter.CompareOp.EQUAL, new RegexStringComparator(".*(" + rowLike + ").*$"))
        scan.setFilter(filter)
        val reult_RDDList: RDD[List[String]] = hbaseContext.hbaseRDD(TableName.valueOf(tableName), scan).map(line => {
            val areaArray = ArrayBuffer[String]()
            val keyrow = Bytes.toString(line._2.getRow);
            val cells = line._2.rawCells()
            var imsi: String = null
            for (cell <- cells) {
                //多个imsi
                val imsis = Bytes.toString(CellUtil.cloneValue(cell)).split(",")
                for (arr <- imsis) {
                    areaArray += arr
                }
            }
            areaArray.toList
        })
        val result_Imsi: RDD[String] = reult_RDDList.flatMap(x => x)
        result_Imsi

    }

    /**
     * 获取hbase连接
     *
     * @return
     */
    def getHbaseConfig(): Configuration = {
        val conf = HBaseConfiguration.create;
        conf.set("hadoop.security.authentication", "kerberos");
        conf.set("hbase.security.authentication", "kerberos");
        val master_principal = "hbase/_HOST@ZHKDC";
        val regionserver_principal = "hbase/_HOST@ZHKDC";
        val krb5_conf = "/etc/krb5.conf";
        System.setProperty("java.security.krb5.conf", krb5_conf)
        conf.set("hbase.master.kerberos.principal", master_principal)
        conf.set("hbase.regionserver.kerberos.principal", regionserver_principal)
        conf.set("hbase.zookeeper.quorum", "hebsjzx-wzjd-master-28-7,hebsjzx-wzjd-master-28-4,hebsjzx-wzjd-master-28-14")
        conf.set("hbase.zookeeper.property.clientPort", "2181")
        conf.set("zookeeper.znode.parent", "/hbase-secure")
        conf
    }


}
