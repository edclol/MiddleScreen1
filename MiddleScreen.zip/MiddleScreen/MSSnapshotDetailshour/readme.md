#快照明细区域人员表（5分钟级别）HBase存储
<br />

##集团环境脚本
spark-submit --master yarn --deploy-mode client --principal huawei_wzjd_kafka --keytab huawei_wzjd_kafka.keytab --conf spark.redis.timeout="100000" --conf "spark.driver.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --conf "spark.executor.extraClassPath=/usr/lib/hbase/lib/metrics-core-2.2.0.jar" --files ./MiddleScreen/conf/spark_jaas.conf,spark_kafka.keytab --conf "spark.driver.extraJavaOptions=-Djava.security.auth.login.config=./MiddleScreen/conf/kafka_client_jaas.conf" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=./spark_jaas.conf" --conf spark.driver.maxResultSize=3g --conf spark.default.parallelism=100 --conf spark.storage.memoryFraction=0.5 --conf spark.network.timeout=360s --conf spark.shuffle.memoryFraction=0.4 --conf spark.yarn.executor.memoryOverhead=4096 --conf spark.ui.port=0 --conf "spark.ui.filters=" --queue root.bdoc.huawei_wzjd_kafka --num-executors 20 --executor-memory 16G --executor-cores 2 --driver-memory 20G --jars ./MiddleScreen/myjars/kafka-clients-0.10.1.1.jar,./MiddleScreen/myjars/kafka_2.10-0.10.1.1.jar,./MiddleScreen/myjars/spark-streaming-kafka-0-10_2.11-2.1.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/myjars/spark-hbaseV2_2.11-2.3.2.jar,/home/huawei_wzjd_kafka/MiddleScreen/mysql-connector-java-5.1.47.jar,/home/huawei_wzjd_kafka/MiddleScreen/commons-pool2-2.0.jar,/home/huawei_wzjd_kafka/MiddleScreen/spark-redis_2.11-2.4.2.jar,/home/huawei_wzjd_kafka/MiddleScreen/jedis-3.2.0.jar --class com.huawei.bigdata.spark.ms.MSSnapshotDetailsH ./MSSnapshotDetailsH.jar DWV_WZMF:t_crowd_data DWV_WZMF:TO_H_EVNT_NS_AREA_IMSI 10.252.31.100 22400 2020082116
参数1：需要读取的hbase表名称(五分钟基站人群明细表)<br />
参数2：需要写入的hbase表名称<br />
参数3：redis的ip地址<br />
参数4：redis的端口号<br />
参数5：自定义的时间粒度到小时<br />
##部署后业务机服务器目录结构
/readme.md &emsp; 帮助<br />
/pom.xml  &emsp;  编译文件<br />l
/src/com/huawei/bigdata/spark/ms/MSSnapshotDetails.scala &emsp;  主流程文件<br />
<br />


##V1.0.0 版本内容更新
* 读取区域信息（redis:area_cell）表获取需要计算的区域列表<br />
* 通过基站信息查询五分钟基站人群明细信息，获取每个基站对应的人群imsi<br />
* 关联cell_lat_lng，将数据组合成基站ID+lat,lng为colum<br />
* 将结果写入hbase中<br />



